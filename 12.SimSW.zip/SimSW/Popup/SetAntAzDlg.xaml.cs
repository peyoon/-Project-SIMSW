﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIMSW
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 조향각 설정 대화상자
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class SetAntAzDlg : Window
    {
        // 화면 갱신 이벤트
        public delegate void Handler_UpdateData();
        public event Handler_UpdateData Event_UpdateData;

        // 통신 패킷 전송 이벤트
        public delegate void Handler_SendTcpPacket(int msgid);
        public event Handler_SendTcpPacket Event_SendTcpPacket;


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public SetAntAzDlg()
        {
            InitializeComponent();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 Closing 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 모달리스일때는 Cancel 취소하고 Hide 해야 한다.
            e.Cancel = true;
            this.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 대화상자 UI 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateDlg()
        {
            // 입력 모드 설정
            if (SimSWData.m_tRadarInfo.angleModeAuto == true)
            {
                uiRadio_Auto.IsChecked = true;
            }
            else
            {
                uiRadio_Manual.IsChecked = true;
            }

            if (SimSWData.m_tRadarInfo.milFlag == true)
            {
                uiRadio_AntAngMil.IsChecked = true;
            }
            else
            {
                uiRadio_AntAngDeg.IsChecked = true;
            }

            // 입력 모드에 따른 처리
            Click_Radio_InputType(null, null);

            // 방위각, 고각 갱신
            uiTextBox_MilAzm.Text = Convert.ToString(SimSWData.m_tRadarInfo.nAntAz);
            uiTextBox_MilEle.Text = Convert.ToString(SimSWData.m_tRadarInfo.nAntEl);

            // mil -> 도 변환 이벤트 콜
            LostFocus_TextBox_MilAzm(null, null);
            LostFocus_TextBox_MilEle(null, null);

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 입력 모드 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Radio_InputType(object sender, RoutedEventArgs e)
        {
            // 자동 입력 모드
            if(uiRadio_Auto.IsChecked == true)
            {
                SimSWData.m_tRadarInfo.angleModeAuto = true;

                uiRadio_AntAngDeg.IsEnabled = false;
                uiRadio_AntAngMil.IsEnabled = false;

                uiTextBox_DegAzm.IsEnabled = false;
                uiTextBox_DegEle.IsEnabled = false;

                uiTextBox_MilAzm.IsEnabled = false;
                uiTextBox_MilEle.IsEnabled = false;

                uiTextBox_DegAzm.Text = "";
                uiTextBox_DegEle.Text = "";

                uiTextBox_MilAzm.Text = "";
                uiTextBox_MilEle.Text = "";
            }
            // 수동 입력 모드
            else
            {
                SimSWData.m_tRadarInfo.angleModeAuto = false;

                uiRadio_AntAngDeg.IsEnabled = true;
                uiRadio_AntAngMil.IsEnabled = true;

                uiTextBox_DegAzm.IsEnabled = true;
                uiTextBox_DegEle.IsEnabled = true;

                uiTextBox_MilAzm.IsEnabled = true;
                uiTextBox_MilEle.IsEnabled = true;

                Click_Radio_AntAng(null, null);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 조향각 입력 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Radio_AntAng(object sender, RoutedEventArgs e)
        {
            // mil 단위
            if(uiRadio_AntAngMil.IsChecked == true)
            {
                uiTextBox_MilAzm.IsEnabled = true;
                uiTextBox_MilEle.IsEnabled = true;

                uiTextBox_DegAzm.IsEnabled = false;
                uiTextBox_DegEle.IsEnabled = false;
            }
            // 도 단위
            else
            {
                uiTextBox_MilAzm.IsEnabled = false;
                uiTextBox_MilEle.IsEnabled = false;

                uiTextBox_DegAzm.IsEnabled = true;
                uiTextBox_DegEle.IsEnabled = true;
            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 도-방위각 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DegAzm(object sender, RoutedEventArgs e)
        {            
            double deg = 0.0;
            OzUtil.StringParse.TextBox_TryParse_Double(uiTextBox_DegAzm, ref deg, 360.0, -360.0, 0.0);

            // 단위 변환 전시
            uiTextBox_MilAzm.Text = Convert.ToString(Scope.ScopeConst.DEG2MIL(deg));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 도-고각 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DegEle(object sender, RoutedEventArgs e)
        {
            double deg = 0.0;
            OzUtil.StringParse.TextBox_TryParse_Double(uiTextBox_DegEle, ref deg, 360.0, -360.0, 0.0);

            // 단위 변환 전시
            uiTextBox_MilEle.Text = Convert.ToString(Scope.ScopeConst.DEG2MIL(deg));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// mil-방위각 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_MilAzm(object sender, RoutedEventArgs e)
        {
            int mil = 0;
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_MilAzm, ref mil, 3600, -3600, 0);

            // 단위 변환 전시
            uiTextBox_DegAzm.Text = string.Format("{0:0.0}", Scope.ScopeConst.MIL2DEG(mil));            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// mil-고각 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_MilEle(object sender, RoutedEventArgs e)
        {
            int mil = 0;
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_MilEle, ref mil, 1800, -1800, 0);

            // 단위 변환 전시
            uiTextBox_DegEle.Text = string.Format("{0:0.0}", Scope.ScopeConst.MIL2DEG(mil));            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 적용 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Ok(object sender, RoutedEventArgs e)
        {
            SimSWData.m_tRadarInfo.nAntAz = Convert.ToInt32(uiTextBox_MilAzm.Text);
            SimSWData.m_tRadarInfo.nAntEl = Convert.ToInt32(uiTextBox_MilEle.Text);

            // 메인화면 갱신
            Event_UpdateData();

            // 메시지 송신
            Event_SendTcpPacket(ICD.Const.MSG_ID_PAN_TILT_ACK);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 닫기 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Cancel(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }


    }
}
