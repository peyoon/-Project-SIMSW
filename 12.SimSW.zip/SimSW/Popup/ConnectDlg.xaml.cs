﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIMSW
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 연동 설정 대화상자
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class ConnectDlg : Window
    {
        // 서버 접속 이벤트 
        public delegate bool Handler_RequestConnectSrv();
        public event Handler_RequestConnectSrv Event_RequestConnectSrv;

        // 서버 종료 이벤트
        public delegate void Handler_RequestDisConnectSrv();
        public event Handler_RequestDisConnectSrv Event_RequestDisConnectSrv;

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public ConnectDlg()
        {
            InitializeComponent();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 Closing 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 모달리스일때는 Cancel 취소하고 Hide 해야 한다.
            e.Cancel = true;
            this.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 대화상자 UI 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateDlg()
        {
            uiIpAddress.IPAddress = SimSWData.m_tConnInfo.strIP;
            uiTextBox_Port.Text = Convert.ToString(SimSWData.m_tConnInfo.nPortCtrl);
            uiTextBox_ID.Text = Convert.ToString(SimSWData.m_tConnInfo.nID);
            uiTextBox_Password.Password = SimSWData.m_tConnInfo.strPassword;

            // 모드에 따라 접속/접속해제 상태를 설정
            switch (SimSWData.m_tConnInfo.eOpMode)
            {
                default:
                case E_SimOpMode.None:
                    uiButton_OK.Content = "접속";
                    uiIpAddress.IsEnabled = true;
                    uiTextBox_Port.IsEnabled = true;
                    uiTextBox_ID.IsEnabled = true;
                    uiTextBox_Password.IsEnabled = true;
                    break;
                case E_SimOpMode.DeActive:
                case E_SimOpMode.Active:
                    uiButton_OK.Content = "접속해제";
                    uiIpAddress.IsEnabled = false;
                    uiTextBox_Port.IsEnabled = false;
                    uiTextBox_ID.IsEnabled = false;
                    uiTextBox_Password.IsEnabled = false;
                    break;

            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 접속/접속해제 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Ok(object sender, RoutedEventArgs e)
        {
            if (SimSWData.m_tConnInfo.eOpMode == E_SimOpMode.None)
            {
                // 암호 확인
                if (SimSWData.m_tConnInfo.strPassword.Equals(uiTextBox_Password.Password) == true)
                {
                    int nTemp = 0;

                    byte[] ip = uiIpAddress.GetByteArray();

                    //GlobalDefine.m_tConnInfo.strIP = Convert.ToString(TextIp..Text);
                    SimSWData.m_tConnInfo.strIP = uiIpAddress.IPAddress;

                    OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_Port, ref nTemp, 50000, 1, 9112);
                    SimSWData.m_tConnInfo.nPortCtrl = nTemp;

                    OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_ID, ref nTemp, 10000, 1, 1);
                    SimSWData.m_tConnInfo.nID = nTemp;

                    // TCP 접속 이벤트 콜
                    if (Event_RequestConnectSrv() == false )
                    {
                        MessageBox.Show("접속에 실패했습니다.", "연동 실패");
                    }
                }
                else
                {
                    MessageBox.Show("패스워드가 틀립니다.", "패스워드 오류");
                }
            }
            else
            {
                // TCP 접속 해제 이벤트 콜
                Event_RequestDisConnectSrv();
            }
            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 닫기 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Cancel(object sender, RoutedEventArgs e)
        {
            // 모달리스이므로 Hide
            this.Hide();
        }

        
    }
}
