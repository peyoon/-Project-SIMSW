﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIMSW
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 위치 설정 대화상자
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class SetPosDlg : Window
    {
        private DataTable   m_DataTableSavePos;     // 위치 저장정보 테이블

        // 화면 갱신 이벤트
        public delegate void Handler_UpdateData();
        public event Handler_UpdateData Event_UpdateData;

        // 통신 패킷 전송 이벤트
        public delegate void Handler_SendTcpPacket(int msgid);
        public event Handler_SendTcpPacket Event_SendTcpPacket;

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public SetPosDlg()
        {
            InitializeComponent();

            // 위치 저장정보 테이블 설정
            m_DataTableSavePos = new DataTable();
            m_DataTableSavePos.Columns.Add("No", typeof(int));
            m_DataTableSavePos.Columns.Add("Lon", typeof(string));
            m_DataTableSavePos.Columns.Add("Lat", typeof(string));
            m_DataTableSavePos.Columns.Add("Alt", typeof(string));
            m_DataTableSavePos.Columns.Add("Azm", typeof(string));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 Closing 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // 모달리스일때는 Cancel 취소하고 Hide 해야 한다.
            e.Cancel = true;

            this.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 대화상자 UI 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateDlg()
        {
            // 좌표계 설정
            if (SimSWData.m_tRadarInfo.bCoordFlag == true)
                uiRadio_PosUnitDms.IsChecked = true;
            else
                uiRadio_PosUnitDeg.IsChecked = true;

            Click_Radio_PosUnit(null, null);

            // 좌표 설정
            uiTextBox_PosAlt.Text = Convert.ToString(SimSWData.m_tRadarInfo.tSysPos.sysAlt);
            uiTextBox_PosAzm.Text = Convert.ToString(SimSWData.m_tRadarInfo.tSysPos.sysAz);

            uiTextBox_PosDegLon.Text = Convert.ToString(SimSWData.m_tRadarInfo.tSysPos.sysLon);
            uiTextBox_PosDegLat.Text = Convert.ToString(SimSWData.m_tRadarInfo.tSysPos.sysLat);
            LostFocus_TextBox_DegLon(null, null);
            LostFocus_TextBox_DegLat(null, null);

            // 위치 저장 테이블 갱신
            UpdateList();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 위치 저장정보 테이블 정보 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void UpdateList()
        {
            m_DataTableSavePos.Clear();
            for (int nCnt = 0; nCnt < SimSWData.m_tRadarInfo.listPosData.Count; nCnt++)
            {
                T_SysPos tSysPos = SimSWData.m_tRadarInfo.listPosData[nCnt];

                string strLon = "";
                string strLat = "";

                // DMS
                if (SimSWData.m_tRadarInfo.bCoordFlag == true)
                {
                    double dDeg = 0.0;
                    int nDeg = 0;
                    int nMin = 0;
                    int nSec = 0;
                    int nMSec = 0;

                    dDeg = tSysPos.sysLon;
                    Scope.ScopeConst.DEG2DMS(dDeg, ref nDeg, ref nMin, ref nSec, ref nMSec);
                    strLon = nDeg.ToString() + '˚' + nMin.ToString("D2") + '′' + nSec.ToString("D2") + '.' + nMSec.ToString("D3");

                    dDeg = tSysPos.sysLat;
                    Scope.ScopeConst.DEG2DMS(dDeg, ref nDeg, ref nMin, ref nSec, ref nMSec);
                    strLat = nDeg.ToString() + '˚' + nMin.ToString("D2") + '′' + nSec.ToString("D2") + '.' + nMSec.ToString("D3");
                }
                // Degree
                else
                {
                    strLon = tSysPos.sysLon.ToString("F8");
                    strLat = tSysPos.sysLat.ToString("F8");
                }

                m_DataTableSavePos.Rows.Add(new object[] { nCnt + 1, strLon, strLat,
                    tSysPos.sysAlt.ToString(), tSysPos.sysAz.ToString() });

            }

            uiDataGrid_SavePos.ItemsSource = null;
            uiDataGrid_SavePos.ItemsSource = m_DataTableSavePos.AsDataView();
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 좌표 단위 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Radio_PosUnit(object sender, RoutedEventArgs e)
        {
            // 도
            if (uiRadio_PosUnitDeg.IsChecked == true)
            {
                SimSWData.m_tRadarInfo.bCoordFlag = false;

                uiTextBox_PosDegLat.IsEnabled = true;
                uiTextBox_PosDegLon.IsEnabled = true;

                uiTextBox_PosDmsLatDeg.IsEnabled = false;
                uiTextBox_PosDmsLatMin.IsEnabled = false;
                uiTextBox_PosDmsLatSec.IsEnabled = false;
                uiTextBox_PosDmsLatMSec.IsEnabled = false;

                uiTextBox_PosDmsLonDeg.IsEnabled = false;
                uiTextBox_PosDmsLonMin.IsEnabled = false;
                uiTextBox_PosDmsLonSec.IsEnabled = false;
                uiTextBox_PosDmsLonMSec.IsEnabled = false;

            }
            // DMS
            else
            {
                SimSWData.m_tRadarInfo.bCoordFlag = true;

                uiTextBox_PosDegLat.IsEnabled = false;
                uiTextBox_PosDegLon.IsEnabled = false;

                uiTextBox_PosDmsLatDeg.IsEnabled = true;
                uiTextBox_PosDmsLatMin.IsEnabled = true;
                uiTextBox_PosDmsLatSec.IsEnabled = true;
                uiTextBox_PosDmsLatMSec.IsEnabled = true;

                uiTextBox_PosDmsLonDeg.IsEnabled = true;
                uiTextBox_PosDmsLonMin.IsEnabled = true;
                uiTextBox_PosDmsLonSec.IsEnabled = true;
                uiTextBox_PosDmsLonMSec.IsEnabled = true;
            }

            // 좌표 단위 변경에 따른 리스트도 갱신
            UpdateList();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// DMS-위도 입력컨트롤 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DmsLat(object sender, RoutedEventArgs e)
        {
            double dDeg = 0.0;
            int nDeg = 0;
            int nMin = 0;
            int nSec = 0;
            int nMSec = 0;

            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLatDeg, ref nDeg, 180, -180, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLatMin, ref nMin, 59, 0, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLatSec, ref nSec, 59, 0, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLatMSec, ref nMSec, 999, 0, 0);

            // DMS -> 도
            Scope.ScopeConst.DMS2DEG(nDeg, nMin, nSec, nMSec, ref dDeg);
            uiTextBox_PosDegLat.Text = string.Format("{0:0.00000000}", dDeg);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// DMS-경도 입력컨트롤 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DmsLon(object sender, RoutedEventArgs e)
        {
            double dDeg = 0.0;
            int nDeg = 0;
            int nMin = 0;
            int nSec = 0;
            int nMSec = 0;

            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLonDeg, ref nDeg, 180, -180, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLonMin, ref nMin, 59, 0, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLonSec, ref nSec, 59, 0, 0);
            OzUtil.StringParse.TextBox_TryParse_Int(uiTextBox_PosDmsLonMSec, ref nMSec, 999, 0, 0);

            // DMS -> 도
            Scope.ScopeConst.DMS2DEG(nDeg, nMin, nSec, nMSec, ref dDeg);
            uiTextBox_PosDegLon.Text = string.Format("{0:0.00000000}", dDeg);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 도-위도 입력컨트롤 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DegLat(object sender, RoutedEventArgs e)
        {
            double dDeg = 0.0;
            int nDeg = 0;
            int nMin = 0;
            int nSec = 0;
            int nMSec = 0;

            OzUtil.StringParse.TextBox_TryParse_Double(uiTextBox_PosDegLat, ref dDeg, 180.0, -180.0, 0.0, 8);

            // 도 -> DMS 
            Scope.ScopeConst.DEG2DMS(dDeg, ref nDeg, ref nMin, ref nSec, ref nMSec);

            uiTextBox_PosDmsLatDeg.Text = Convert.ToString(nDeg);
            uiTextBox_PosDmsLatMin.Text = Convert.ToString(nMin);
            uiTextBox_PosDmsLatSec.Text = Convert.ToString(nSec);
            uiTextBox_PosDmsLatMSec.Text = Convert.ToString(nMSec);

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 도-경도 입력컨트롤 Lost Focuse 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LostFocus_TextBox_DegLon(object sender, RoutedEventArgs e)
        {
            double dDeg = 0.0;
            int nDeg = 0;
            int nMin = 0;
            int nSec = 0;
            int nMSec = 0;

            OzUtil.StringParse.TextBox_TryParse_Double(uiTextBox_PosDegLon, ref dDeg, 180.0, -180.0, 0.0, 8);

            // 도 -> DMS 
            Scope.ScopeConst.DEG2DMS(dDeg, ref nDeg, ref nMin, ref nSec, ref nMSec);

            uiTextBox_PosDmsLonDeg.Text = Convert.ToString(nDeg);
            uiTextBox_PosDmsLonMin.Text = Convert.ToString(nMin);
            uiTextBox_PosDmsLonSec.Text = Convert.ToString(nSec);
            uiTextBox_PosDmsLonMSec.Text = Convert.ToString(nMSec);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 위치 저장 리스트 Mouse Down 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void MouseDown_DataGrid_SavePos(object sender, MouseButtonEventArgs e)
        {
            int index = uiDataGrid_SavePos.SelectedIndex;

            if (index > -1)
            {
                // 선택된 정보로 정보 갱신
                T_SysPos tSysPos = SimSWData.m_tRadarInfo.listPosData[index];

                uiTextBox_PosAlt.Text = Convert.ToString(tSysPos.sysAlt);
                uiTextBox_PosAzm.Text = Convert.ToString(tSysPos.sysAz);

                uiTextBox_PosDegLon.Text = Convert.ToString(tSysPos.sysLon);
                uiTextBox_PosDegLat.Text = Convert.ToString(tSysPos.sysLat);
                LostFocus_TextBox_DegLon(null, null);
                LostFocus_TextBox_DegLat(null, null);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 적용 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Ok(object sender, RoutedEventArgs e)
        {
            SimSWData.m_tRadarInfo.tSysPos.sysLon = Convert.ToDouble(uiTextBox_PosDegLon.Text);
            SimSWData.m_tRadarInfo.tSysPos.sysLat = Convert.ToDouble(uiTextBox_PosDegLat.Text);
            SimSWData.m_tRadarInfo.tSysPos.sysAlt = Convert.ToInt32(uiTextBox_PosAlt.Text);
            SimSWData.m_tRadarInfo.tSysPos.sysAz = Convert.ToInt32(uiTextBox_PosAzm.Text);

            // 메인화면 갱신
            Event_UpdateData();

            // 메시지 송신
            Event_SendTcpPacket(ICD.Const.MSG_ID_GPS_DATA_ACK);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 닫기 버튼 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_Cancel(object sender, RoutedEventArgs e)
        {
            this.Hide();
        }

    }
}
