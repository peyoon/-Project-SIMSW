﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SIMSW
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 윈도우 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class MainWindow : Window
    {
        // 설정 대화상자
        private ConnectDlg    m_ConnectDlg;     // 연동 설정 대화상자
        private SetPosDlg     m_SetPosDlg;      // 위치 설정 대화상자
        private SetAntAzDlg   m_SetAntAzDlg;    // 조향각 설정 대화상자
        

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public MainWindow()
        {
            InitializeComponent();

            m_ConnectDlg = null;
            m_SetAntAzDlg = null;
            m_SetPosDlg = null;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 로딩 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Loaded_Window(object sender, RoutedEventArgs e)
        {
            // Data 초기화
            SimSWData.Init();

            // 설정 INI 파일 로딩
            LoadINIFile();

            // 설정 대화상자 생성 및 event 등록
            m_ConnectDlg = new ConnectDlg();
            m_ConnectDlg.Event_RequestConnectSrv += new ConnectDlg.Handler_RequestConnectSrv(this.ConnectSrv);
            m_ConnectDlg.Event_RequestDisConnectSrv += new ConnectDlg.Handler_RequestDisConnectSrv(this.DisConnectSrv);

            m_SetPosDlg = new SetPosDlg();
            m_SetPosDlg.Event_UpdateData += new SetPosDlg.Handler_UpdateData(this.UpdateData);
            m_SetPosDlg.Event_SendTcpPacket += new SetPosDlg.Handler_SendTcpPacket(this.SendTcpPacket);

            m_SetAntAzDlg = new SetAntAzDlg();
            m_SetAntAzDlg.Event_UpdateData += new SetAntAzDlg.Handler_UpdateData(this.UpdateData);
            m_SetAntAzDlg.Event_SendTcpPacket += new SetAntAzDlg.Handler_SendTcpPacket(this.SendTcpPacket);


            ////////////////////////////////////////////////////
            /// MainWindw_Scope 초기화 - Scope GL
            InitScope();

            ////////////////////////////////////////////////////
            /// MainWindw_Comm 초기화 - 통신
            InitComm();

            // 화면 갱신
            UpdateData();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 윈도우 Closing 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Closing_Window(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (MessageBox.Show("프로그램을 종료할까요?", "종료 확인", MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No) == MessageBoxResult.Yes)
            {
                Environment.Exit(0); //모두 종료
                System.Diagnostics.Process.GetCurrentProcess().Kill(); //관련프로세스 강제 종료
            }
            else
            {
                e.Cancel = true;
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 메인 화면 갱신
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void UpdateData()
        {
            // 위치 정보 갱신
            uiTextBox_RadarLon.Text = SimSWData.m_tRadarInfo.tSysPos.sysLon.ToString("F8");
            uiTextBox_RadarLat.Text = SimSWData.m_tRadarInfo.tSysPos.sysLat.ToString("F8");
            uiTextBox_RadarAlt.Text = SimSWData.m_tRadarInfo.tSysPos.sysAlt.ToString();
            uiTextBox_RadarAzm.Text = SimSWData.m_tRadarInfo.tSysPos.sysAz.ToString();

            uiTextBox_RadarAntAzm.Text = SimSWData.m_tRadarInfo.nAntAz.ToString();
            uiTextBox_RadarAntEle.Text = SimSWData.m_tRadarInfo.nAntEl.ToString();

            // 운용모드 갱신
            switch (SimSWData.m_tConnInfo.eOpMode)
            {
                default:
                case E_SimOpMode.None:
                    uiLabel_OpMode.Content = "운용 종료";
                    uiLabel_OpMode.Background = new SolidColorBrush(Color.FromRgb(200, 200, 200));
                    uiGroupBox_Info.IsEnabled = false;
                    uiGroupBox_AntInfo.IsEnabled = false;
                    uiGroupBox_ZoomInfo.IsEnabled = false;
                    break;
                case E_SimOpMode.DeActive:
                    uiLabel_OpMode.Content = "운용 대기";
                    uiLabel_OpMode.Background = new SolidColorBrush(Color.FromRgb(0, 255, 255));
                    uiGroupBox_Info.IsEnabled = true;
                    uiGroupBox_AntInfo.IsEnabled = true;
                    uiGroupBox_ZoomInfo.IsEnabled = true;
                    break;
                case E_SimOpMode.Active:
                    uiLabel_OpMode.Content = "운용중";
                    uiLabel_OpMode.Background = new SolidColorBrush(Color.FromRgb(0, 255, 0));
                    uiGroupBox_Info.IsEnabled = true;
                    uiGroupBox_AntInfo.IsEnabled = true;
                    uiGroupBox_ZoomInfo.IsEnabled = true;
                    break;
            }

            // 줌 배율 정보 UI
            if (SimSWData.m_tConnInfo.eOpMode == E_SimOpMode.None)
            {
                uiToggleButton_RadarZoomX3.IsChecked = false;
                uiToggleButton_RadarZoomX11.IsChecked = false;
                uiToggleButton_RadarZoomX40.IsChecked = false;
            }
            else
            {
                switch (SimSWData.m_tRadarInfo.eZoomRate)
                {
                    case E_ZoomRate.X3:
                        uiToggleButton_RadarZoomX3.IsChecked = true;
                        uiToggleButton_RadarZoomX11.IsChecked = false;
                        uiToggleButton_RadarZoomX40.IsChecked = false;
                        break;
                    case E_ZoomRate.X11:
                        uiToggleButton_RadarZoomX3.IsChecked = false;
                        uiToggleButton_RadarZoomX11.IsChecked = true;
                        uiToggleButton_RadarZoomX40.IsChecked = false;
                        break;
                    case E_ZoomRate.X40:
                        uiToggleButton_RadarZoomX3.IsChecked = false;
                        uiToggleButton_RadarZoomX11.IsChecked = false;
                        uiToggleButton_RadarZoomX40.IsChecked = true;
                        break;
                    default:
                        break;
                }
            }

            // 모달리스 대화상자 갱신
            if (m_ConnectDlg.IsVisible == true)
                m_ConnectDlg.UpdateDlg();

            if (m_SetPosDlg.IsVisible == true)
                m_SetPosDlg.UpdateDlg();

            if (m_SetAntAzDlg.IsVisible == true)
                m_SetAntAzDlg.UpdateDlg();

            ////////////////////////////////////////////////////
            /// MainWindw_Scope.cs 구현
            // Update Scope GL Render
            UpdateScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 초기설정파일(ini) 파일 읽기
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LoadINIFile()
        {
            string strINIFilePath = @"./SimSW.ini";
            StringBuilder sbBuffer = new StringBuilder();

            // 연동 정보
            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "IP", "", sbBuffer, 256, strINIFilePath);
            SimSWData.m_tConnInfo.strIP = sbBuffer.ToString();

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "PORT_CTRL", "", sbBuffer, 256, strINIFilePath);
            SimSWData.m_tConnInfo.nPortCtrl = Convert.ToInt32(sbBuffer.ToString());

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "ID", "", sbBuffer, 256, strINIFilePath);
            SimSWData.m_tConnInfo.nID = Convert.ToInt32(sbBuffer.ToString());

            OzWin32.Win32DLL.GetPrivateProfileString("CONNECT", "PASSWORD", "", sbBuffer, 256, strINIFilePath);
            SimSWData.m_tConnInfo.strPassword = sbBuffer.ToString();

            // 레이다 위치 저장
            int nSaveNum = 0;
            SimSWData.m_tRadarInfo.listPosData.Clear();

            OzWin32.Win32DLL.GetPrivateProfileString("POS_SAVE", "SAVE_NUM", "", sbBuffer, 256, strINIFilePath);
            nSaveNum = Convert.ToInt32(sbBuffer.ToString());
            for (int nSaveCnt = 0; nSaveCnt < nSaveNum; nSaveCnt++)
            {
                string strKeyName;

                strKeyName = "SAVE" + (nSaveCnt + 1).ToString();
                OzWin32.Win32DLL.GetPrivateProfileString("POS_SAVE", strKeyName, "", sbBuffer, 256, strINIFilePath);

                string[] strSysInfo = sbBuffer.ToString().Split(',');

                T_SysPos tPosData = new T_SysPos();
                tPosData.sysLon = Convert.ToDouble(strSysInfo[0]);
                tPosData.sysLat = Convert.ToDouble(strSysInfo[1]);
                tPosData.sysAlt = Convert.ToInt32(strSysInfo[2]);
                tPosData.sysAz = Convert.ToInt32(strSysInfo[3]);

                SimSWData.m_tRadarInfo.listPosData.Add(tPosData);
            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 메뉴-연동설정 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_MenuButton_Connect(object sender, RoutedEventArgs e)
        {
            if (m_ConnectDlg.IsVisible == false)
            {
                m_ConnectDlg.UpdateDlg();
                m_ConnectDlg.Show();
            }
            else
                m_ConnectDlg.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 메뉴-PPI 각도 간격 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_MenuRadioPpiAng(object sender, RoutedEventArgs e)
        {
            if (uiMenuRadio_PpiAng200.IsChecked == true)
            {
                SimSWData.m_tPpiScopeSetting.eAngGap = Scope.E_ScopeAngGap._200;
            }
            else if (uiMenuRadio_PpiAng400.IsChecked == true)
            {
                SimSWData.m_tPpiScopeSetting.eAngGap = Scope.E_ScopeAngGap._400;
            }
            else if (uiMenuRadio_PpiAng800.IsChecked == true)
            {
                SimSWData.m_tPpiScopeSetting.eAngGap = Scope.E_ScopeAngGap._800;
            }
            else //if (uiMenuRadio_PpiAngOff.IsChecked == true)
            {
                SimSWData.m_tPpiScopeSetting.eAngGap = Scope.E_ScopeAngGap.OFF;
            }

            // Scope 갱신
            UpdateScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 메뉴-RHI 각도 간격 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_MenuRadio_RhiAng(object sender, RoutedEventArgs e)
        {
            if (uiMenuRadio_RhiAng200.IsChecked == true)
            {
                SimSWData.m_tRhiScopeSetting.eAngGap = Scope.E_ScopeAngGap._200;
            }
            else if (uiMenuRadio_RhiAng400.IsChecked == true)
            {
                SimSWData.m_tRhiScopeSetting.eAngGap = Scope.E_ScopeAngGap._400;
            }
            else if (uiMenuRadio_RhiAng800.IsChecked == true)
            {
                SimSWData.m_tRhiScopeSetting.eAngGap = Scope.E_ScopeAngGap._800;
            }
            else //if (uiMenuRadio_RhiAngOff.IsChecked == true)
            {
                SimSWData.m_tRhiScopeSetting.eAngGap = Scope.E_ScopeAngGap.OFF;
            }

            // Scope 갱신
            UpdateScope();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레이다 위치 저장 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_RadarSavePos(object sender, RoutedEventArgs e)
        {
            // 위치정보 저장
            SimSWData.m_tRadarInfo.listPosData.Add(SimSWData.m_tRadarInfo.tSysPos);

            if (SimSWData.m_tRadarInfo.listPosData.Count > 5)
                SimSWData.m_tRadarInfo.listPosData.RemoveAt(0);

            //////////////////////////////////////////////////////////////////////////
            // ini 파일 저장
            string strINIFilePath = "./TODSim.ini";

            List<T_SysPos> listPosData = new List<T_SysPos>();

            listPosData = SimSWData.m_tRadarInfo.listPosData;

            int nSaveNum = listPosData.Count;
            OzWin32.Win32DLL.WritePrivateProfileString("POS_SAVE", "SAVE_NUM", nSaveNum.ToString(), strINIFilePath);

            for (int listCnt = 0; listCnt < 5; listCnt++)
            {
                string strKeyName;
                string strBuffer;

                strKeyName = "SAVE" + (listCnt + 1).ToString();

                if (listCnt < nSaveNum)
                {
                    strBuffer = listPosData[listCnt].sysLon.ToString() + ','
                        + listPosData[listCnt].sysLat.ToString() + ','
                        + listPosData[listCnt].sysAlt.ToString() + ','
                        + listPosData[listCnt].sysAz.ToString();
                }
                else
                {
                    strBuffer = "";
                }

                OzWin32.Win32DLL.WritePrivateProfileString("POS_SAVE", strKeyName, strBuffer, strINIFilePath);
            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 수동입력 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_RadarSetPos(object sender, RoutedEventArgs e)
        {
            // 수동 위치 입력 대화상자 전시
            if (m_SetPosDlg.IsVisible == false)
            {
                m_SetPosDlg.UpdateDlg();
                m_SetPosDlg.Show();
            }
            else
                m_SetPosDlg.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 조향각 설정 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_Button_RadarSetAnt(object sender, RoutedEventArgs e)
        {
            // 조향각 설정 대화상자 전시
            if (m_SetAntAzDlg.IsVisible == false)
            {
                m_SetAntAzDlg.UpdateDlg();
                m_SetAntAzDlg.Show();
            }
            else
                m_SetAntAzDlg.Hide();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 줌배열 X3 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_RadarZoomX3(object sender, RoutedEventArgs e)
        {
            SimSWData.m_tRadarInfo.eZoomRate = E_ZoomRate.X3;

            // 화면 갱신
            UpdateData();

            // send packet
            // 줌 배율 변경시 A, B 두개 보내줘야 한다.
            SendTcpPacket(ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK);
            SendTcpPacket(ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 줌배열 X11 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_RadarZoomX11(object sender, RoutedEventArgs e)
        {
            SimSWData.m_tRadarInfo.eZoomRate = E_ZoomRate.X11;

            // 화면 갱신
            UpdateData();

            // send packet
            // 줌 배율 변경시 A, B 두개 보내줘야 한다.
            SendTcpPacket(ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK);
            SendTcpPacket(ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 줌배열 X40 클릭 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_ToggleButton_RadarZoomX40(object sender, RoutedEventArgs e)
        {
            SimSWData.m_tRadarInfo.eZoomRate = E_ZoomRate.X40;

            // 화면 갱신
            UpdateData();

            // send packet
            // 줌 배율 변경시 A, B 두개 보내줘야 한다.
            SendTcpPacket(ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK);
            SendTcpPacket(ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK);
        }

        
    }
}
