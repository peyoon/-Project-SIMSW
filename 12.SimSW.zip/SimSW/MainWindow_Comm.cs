﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace SIMSW
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 메인 윈도우 클래스 - 통신 관리
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public partial class MainWindow : Window
    {
        private OzNet.TCPClient     m_cTcpClient;           // TCP Client 모듈
        private Thread              m_threadRcvPacket;      // 통신 수신 스레드
        private Timer               m_timerCycleSending;    // 주기 송신용 타이머

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 통신 초기화
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitComm()
        {
            // 통신 모듈 생성
            m_cTcpClient = new OzNet.TCPClient();

            // 주기 송신용 타이머 생성
            m_timerCycleSending = new Timer(Timer_CycleSending);
            m_timerCycleSending.Change(0, 1000);    // 1초 타이머

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 접속
        /// 파라미터 : -
        /// 반 환 값 : 서버 접속 성공 유무
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool ConnectSrv()
        {
            bool bConnected = false;

            // 서버 접속
            if (m_cTcpClient.Connect(SimSWData.m_tConnInfo.strIP, SimSWData.m_tConnInfo.nPortCtrl) != null)
            {
                // 서버 접속에 성공하면 수신 스레드 생성
                m_threadRcvPacket = new Thread(new ThreadStart(ProcThread_RcvPacket));
                m_threadRcvPacket.IsBackground = true;
                m_threadRcvPacket.Start();

                SimSWData.m_tConnInfo.eOpMode = E_SimOpMode.DeActive;

                bConnected = true;
            }
            else
            {
                MessageBox.Show("연동 실패", "연동 실패");

                bConnected = false;
            }

            UpdateData();

            return bConnected;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 서버 접속 종료
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DisConnectSrv()
        {
            // 접속 종료
            m_cTcpClient.Disconnect();

            // 접속 종료 시 정보 초기화
            SimSWData.m_tConnInfo.eOpMode = E_SimOpMode.None;
            SimSWData.m_tRadarInfo.Clear();

            // 화면 갱신
            UpdateData();
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 패킷 송신
        /// 파라미터 :  [in] msgid  - 메시지 ID
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SendTcpPacket(int msgid)
        {

            switch (msgid)
            {
                /****************************************************************************/
                /* A 배율 제어 명령 ACK, MSG_ID : 0xAA02									*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK:    // = (0xAA02);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_AZoomCtrlAck());
                        ICD.ST_AZoomCtrlAck packetsnd = new ICD.ST_AZoomCtrlAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        packetsnd.zoomRate = Convert.ToUInt32(SimSWData.m_tRadarInfo.eZoomRate);                        

                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_AZoomCtrlAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);
                        
                    }
                    break;

                /****************************************************************************/
                /* B 배율 제어 명령 ACK, MSG_ID : 0xAB02									*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK:    // = (0xAB02);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_BZoomCtrlAck());
                        ICD.ST_BZoomCtrlAck packetsnd = new ICD.ST_BZoomCtrlAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        switch (SimSWData.m_tRadarInfo.eZoomRate)
                        {
                            case E_ZoomRate.X3:
                                packetsnd.zoomRate = 3;
                                break;
                            case E_ZoomRate.X11:
                                packetsnd.zoomRate = 11;
                                break;
                            case E_ZoomRate.X40:
                                packetsnd.zoomRate = 40;
                                break;
                            default:
                                break;
                        }

                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_BZoomCtrlAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);
                    }
                    break;

                /****************************************************************************/
                /* 방위각고각 ACK, MSG_ID : 0xAC02											*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_PAN_TILT_ACK:         // = (0xAC02);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_PanTiltAck());
                        ICD.ST_PanTiltAck packetsnd = new ICD.ST_PanTiltAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_PAN_TILT_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        packetsnd.pan = (ushort)SimSWData.m_tRadarInfo.nAntAz;
                        packetsnd.tilt = (short)SimSWData.m_tRadarInfo.nAntEl;


                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_PanTiltAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);
                        
                    }
                    break;

                /****************************************************************************/
                /* 상태 요청 ACK, MSG_ID : 0xAD01										*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_STATUS_REQ_ACK:   // = (0xAD01);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_StatusReqAck());
                        ICD.ST_StatusReqAck packetsnd = new ICD.ST_StatusReqAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_STATUS_REQ_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        // 고정값 0x02 : 자동정렬 완료으로 설정
                        packetsnd.status = 0x02;


                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_StatusReqAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);

                    }
                    break;

                /****************************************************************************/
                /* GPS 데이터 ACK, MSG_ID : 0xAE01											*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_GPS_DATA_ACK:         // = (0xAE01);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_GpsDataAck());
                        ICD.ST_GpsDataAck packetsnd = new ICD.ST_GpsDataAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_GPS_DATA_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        packetsnd.latitude = (float)SimSWData.m_tRadarInfo.tSysPos.sysLat;
                        if (SimSWData.m_tRadarInfo.tSysPos.sysLat > 0.0)
                            packetsnd.indicatorNS = 'N';  // N
                        else
                            packetsnd.indicatorNS = 'S';  // S
                        packetsnd.longitude = (float)SimSWData.m_tRadarInfo.tSysPos.sysLon;
                        if (SimSWData.m_tRadarInfo.tSysPos.sysLon > 0.0)
                            packetsnd.indicatorEW = 'E';  // E
                        else
                            packetsnd.indicatorEW = 'W';  // W
                        packetsnd.altitude = (ushort)SimSWData.m_tRadarInfo.tSysPos.sysAlt;    // MSL

                        DateTime curTime = DateTime.Now;

                        packetsnd.year = (ushort)curTime.Year;
                        packetsnd.month = (byte)curTime.Month;
                        packetsnd.day = (byte)curTime.Day;
                        packetsnd.hour = (byte)curTime.Hour;
                        packetsnd.minute = (byte)curTime.Minute;
                        packetsnd.second = (byte)curTime.Second;
                        packetsnd.static1 = 1;     // 고정값
                        packetsnd.static2 = 10;  // 고정값
                        packetsnd.static3 = 1; // 고정값


                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_GpsDataAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);


                    }
                    break;

                /****************************************************************************/
                /* 시스템 로그인 상태 ACK, MSG_ID : 0xFFAA							*/
                /****************************************************************************/

                case ICD.Const.MSG_ID_LOGIN_ACK:        // = (0xFFAA);
                    {
                        int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                        int nPktSize = Marshal.SizeOf(new ICD.ST_LoginAck());
                        ICD.ST_LoginAck packetsnd = new ICD.ST_LoginAck();

                        //////////////////////////////////////////////////////////////////////////
                        // header
                        packetsnd.msgHeader.id = ICD.Const.MSG_SIMSW_INDICATOR;      // ID : 0xFEDC
                        packetsnd.msgHeader.srcId = (byte)SimSWData.m_tConnInfo.nID;
                        packetsnd.msgHeader.destId = ICD.Const.SIMSRV_ID;
                        packetsnd.msgHeader.msgId = ICD.Const.MSG_ID_LOGIN_ACK;
                        packetsnd.msgHeader.dataSize = (ushort)(nPktSize - nHeaderSize);

                        //////////////////////////////////////////////////////////////////////////
                        // body
                        if (SimSWData.m_tConnInfo.eOpMode == E_SimOpMode.Active)
                            packetsnd.status = 0x1;
                        else
                            packetsnd.status = 0x0;


                        //////////////////////////////////////////////////////////////////////////
                        // 메시지 전송
#if (_SwapEndian)
                        packetsnd.SwapEndian();
#endif

                        byte[] byPacketSnd = new byte[nPktSize];
                        byPacketSnd = OzUtil.MarshalHelper.StructToByte<ICD.ST_LoginAck>(packetsnd);

                        int nSendSize = m_cTcpClient.Send(byPacketSnd, nPktSize);

                        // add log
                        m_cLogComm.AddLog(byPacketSnd, false);

                    }
                    break;
                                    

                default:
                    break;
            }

            //  화면 갱신
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
            {
                // Scope만 갱신 - UI 정보를 새로 갱신하면 입력값 날라가니 UI는 제외..                                
                UpdateScope();                
            }));

        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 스레드 수행 - 통신 수신 스레드
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcThread_RcvPacket()
        {
            while (m_cTcpClient.IsClientRun() == true)
            {
                //////////////////////////
                // header 수신
                int nRcvSize = 0;
                int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());
                int nDataSize = 0;

                ICD.ST_MsgHeader tHeader = new ICD.ST_MsgHeader();

                byte[] byRcvBuffer = null;
                byte[] byHeader = new byte[nHeaderSize];
                byte[] byData;

                nRcvSize = nHeaderSize;
                byHeader = m_cTcpClient.Recieve(nRcvSize);

                if (byHeader != null)
                {
                    tHeader = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_MsgHeader>(byHeader, nHeaderSize);

#if (_SwapEndian)
                    tHeader.SwapEndian();
#endif

                    // 메시지 별 데이터 수신
                    switch (tHeader.msgId)
                    {
                        /****************************************************************************/
                        /* A 배율 제어 명령, MSG_ID : 0xAA02										*/
                        /****************************************************************************/
                        //#define MSG_ID_A_ZOOM_CTRL		(0xAA02)
                        case ICD.Const.MSG_ID_A_ZOOM_CTRL:    // = (0xAA02);
                            {
                                nRcvSize = nDataSize = tHeader.dataSize;

                                byData = new byte[nDataSize];
                                byData = m_cTcpClient.Recieve(nRcvSize);

                                if (byData != null)
                                {
                                    byRcvBuffer = new byte[nHeaderSize + nDataSize];
                                    Buffer.BlockCopy(byHeader, 0, byRcvBuffer, 0, nHeaderSize);
                                    Buffer.BlockCopy(byData, 0, byRcvBuffer, nHeaderSize, nDataSize);

                                    ICD.ST_AZoomCtrl tPacket = new ICD.ST_AZoomCtrl();
                                    tPacket = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_AZoomCtrl>(byRcvBuffer, nHeaderSize + nDataSize);

#if (_SwapEndian)
                                    tPacket.SwapEndian();
#endif

                                    SimSWData.m_tRadarInfo.eZoomRate = (E_ZoomRate)tPacket.zoomRate;


                                    // add log
                                    m_cLogComm.AddLog(byRcvBuffer, true);

                                    /****************************************************************************/
                                    /* A 배율 제어 명령 ACK, MSG_ID : 0xAA02									*/
                                    /****************************************************************************/
                                    SendTcpPacket(ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK);

                                }

                            }
                            break;

                        /****************************************************************************/
                        /* B 배율 제어 명령, MSG_ID : 0xAB02										*/
                        /****************************************************************************/
                        //#define MSG_ID_B_ZOOM_CTRL	(0xAB02)
                        case ICD.Const.MSG_ID_B_ZOOM_CTRL:    // = (0xAB02);
                            {
                                nRcvSize = nDataSize = tHeader.dataSize;

                                byData = new byte[nDataSize];
                                byData = m_cTcpClient.Recieve(nRcvSize);

                                if (byData != null)
                                {
                                    byRcvBuffer = new byte[nHeaderSize + nDataSize];
                                    Buffer.BlockCopy(byHeader, 0, byRcvBuffer, 0, nHeaderSize);
                                    Buffer.BlockCopy(byData, 0, byRcvBuffer, nHeaderSize, nDataSize);

                                    ICD.ST_BZoomCtrl tPacket = new ICD.ST_BZoomCtrl();
                                    tPacket = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_BZoomCtrl>(byRcvBuffer, nHeaderSize + nDataSize);

#if (_SwapEndian)
                                    tPacket.SwapEndian();
#endif

                                    // MSG_ID_A_ZOOM_CTRL 메시지와 같이 들어온다
                                    // 처리는 동일하나 MSG_ID_A_ZOOM_CTRL 메시지를 우선으로 처리하기에
                                    // 이 메시지는 받기만 하고 처리는 보류!!!
                                    //GlobalDefine.m_tSIMSWInfo.eZoomRate = tPacket.eZoomRate;

                                    // add log
                                    m_cLogComm.AddLog(byRcvBuffer, true);

                                    /****************************************************************************/
                                    /* B 배율 제어 명령 ACK, MSG_ID : 0xAB02									*/
                                    /****************************************************************************/
                                    SendTcpPacket(ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK);

                                }

                            }
                            break;

                        /****************************************************************************/
                        /* 방향조종기 지점 탐색, MSG_ID : 0xAC03									*/
                        /****************************************************************************/
                        //#define MSG_ID_CONTROLLER_POS_SEARCH		(0xAC03)
                        case ICD.Const.MSG_ID_CONTROLLER_POS_SEARCH:    // = (0xAC03);
                            {
                                nRcvSize = nDataSize = tHeader.dataSize;
                                byData = new byte[nDataSize];
                                byData = m_cTcpClient.Recieve(nRcvSize);

                                if (byData != null)
                                {
                                    byRcvBuffer = new byte[nHeaderSize + nDataSize];
                                    Buffer.BlockCopy(byHeader, 0, byRcvBuffer, 0, nHeaderSize);
                                    Buffer.BlockCopy(byData, 0, byRcvBuffer, nHeaderSize, nDataSize);

                                    ICD.ST_ControllerPos_Search tPacket = new ICD.ST_ControllerPos_Search();
                                    tPacket = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_ControllerPos_Search>(byRcvBuffer, nHeaderSize + nDataSize);

#if (_SwapEndian)
                                    tPacket.SwapEndian();
#endif

                                    SimSWData.m_tRadarInfo.nAntAz = tPacket.pan;
                                    SimSWData.m_tRadarInfo.nAntEl = tPacket.tilt;

                                    // add log
                                    m_cLogComm.AddLog(byRcvBuffer, true);

                                    /****************************************************************************/
                                    /* 방위각고각 ACK, MSG_ID : 0xAC02											*/
                                    /****************************************************************************/
                                    SendTcpPacket(ICD.Const.MSG_ID_PAN_TILT_ACK);

                                }
                            }
                            break;

                        /****************************************************************************/
                        /* 상태 요청, MSG_ID : 0xAD01											*/
                        /****************************************************************************/
                        //#define MSG_ID_STATUS_REQ	(0xAD01)
                        case ICD.Const.MSG_ID_STATUS_REQ:   // = (0xAD01);
                            {
                                // 이 메시지는 헤더만 있다. 
                                // 골 데이터 수신부 처리 안하고 ACK처리만 한다.

                                // add log
                                m_cLogComm.AddLog(byHeader, true);

                                /****************************************************************************/
                                /* 상태 요청 ACK, MSG_ID : 0xAD01										*/
                                /****************************************************************************/
                                SendTcpPacket(ICD.Const.MSG_ID_STATUS_REQ_ACK);

                            }
                            break;

                        /****************************************************************************/
                        /* 시스템 로그인, MSG_ID : 0xFFAA									*/
                        /****************************************************************************/
                        //#define MSG_ID_LOGIN		(0xFFAA)
                        case ICD.Const.MSG_ID_LOGIN:    // = (0xFFAA);
                            {
                                nRcvSize = nDataSize = tHeader.dataSize;

                                byData = new byte[nDataSize];
                                byData = m_cTcpClient.Recieve(nRcvSize);

                                if (byData != null)
                                {
                                    byRcvBuffer = new byte[nHeaderSize + nDataSize];
                                    Buffer.BlockCopy(byHeader, 0, byRcvBuffer, 0, nHeaderSize);
                                    Buffer.BlockCopy(byData, 0, byRcvBuffer, nHeaderSize, nDataSize);

                                    ICD.ST_Login tPacket = new ICD.ST_Login();
                                    tPacket = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_Login>(byRcvBuffer, nHeaderSize + nDataSize);

#if (_SwapEndian)
                                    tPacket.SwapEndian();
#endif

                                    if (tPacket.req == 0x00) // 현재 로그인 상태 요청
                                        SimSWData.m_tConnInfo.eOpMode = E_SimOpMode.Active;
                                    else
                                        SimSWData.m_tConnInfo.eOpMode = E_SimOpMode.DeActive;

                                    // add log
                                    m_cLogComm.AddLog(byRcvBuffer, true);

                                    /****************************************************************************/
                                    /* 시스템 로그인 상태 ACK, MSG_ID : 0xFFAA							*/
                                    /****************************************************************************/
                                    SendTcpPacket(ICD.Const.MSG_ID_LOGIN_ACK);

                                }
                            }
                            break;                  
                       
                        default:
                            break;
                    }

                    // 데이터 반영 갱신
                    Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
                    {
                        UpdateData();
                    }));
                }
            }

            // while 문을 나왔다는건 통신이 중단 되었다는 소리
            // 종료처리를 해주자.
            if (SimSWData.m_tConnInfo.eOpMode != E_SimOpMode.None)
            {
                SimSWData.m_tConnInfo.eOpMode = E_SimOpMode.None;
                SimSWData.m_tRadarInfo.Clear();

                Dispatcher.BeginInvoke(DispatcherPriority.Normal, new Action(() =>
                {
                    UpdateData();
                }));
            }

        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 타이머 수행 - 주기 송신 수행
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 26일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Timer_CycleSending(Object state)
        {
            if (SimSWData.m_tConnInfo.eOpMode != E_SimOpMode.None)
            {
                SendTcpPacket(ICD.Const.MSG_ID_GPS_DATA_ACK);
            }

        }

    }
}
