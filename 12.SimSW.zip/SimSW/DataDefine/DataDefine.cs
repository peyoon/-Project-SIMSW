﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SIMSW
{
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	#region 내부 데이터 구조체 정의

	// 운용모드
	public enum E_SimOpMode
	{
		None,		// 운용불가 (TCP 연결X)
		DeActive,   // 운용대기	(TCP 연결O, 로그인 X)
		Active      // 운용중	(TCP 연결O, 로그인 O)
	};

	// 줌 배율
	public enum E_ZoomRate
	{
		X3	= 0x01,
		X11 = 0x02,
		X40 = 0x04,
	};
	
	// 연동 정보 구조체
    public struct T_ConnInfo
	{
		public E_SimOpMode	eOpMode;		// 운용모드
		public string		strIP;			// IP
		public int			nPortCtrl;		// Port
		public int			nID;			// 연동 ID
		public string		strPassword;	// 패스워드

        public T_ConnInfo(bool bInit)
        {
			eOpMode = E_SimOpMode.None;			
			strIP = "127.0.0.1";
			nPortCtrl = 9112;
			nID = 1;
			strPassword = "1234";

			if (bInit == false)
            {				
				Console.WriteLine("T_ConnInfo 초기화 안함.");
            }
        }

	};

    // 시스템 위치, 자세 정보 구조체
    public struct T_SysPos
	{
		public double	sysLon;		// 경도
		public double	sysLat;		// 위도
		public int		sysAlt;		// 고도
		public int		sysAz;		// 정치각

		public T_SysPos(bool bInit)
        {
            sysLon = 0.0;
            sysLat = 0.0;
            sysAlt = 0;
            sysAz = 0;

			if (bInit == false)
			{
				Console.WriteLine("T_SysPos 초기화 안함.");
			}
		}
    };


    // Sim SW 정보 구조체
    public struct T_SimInfo
	{
		public T_SysPos		tSysPos;        // 시스템 위치, 자세 정보
        public int			nAntAz;			// 조향 방위각 [mil]
		public int			nAntEl;			// 조향 고각 [mil]
		public E_ZoomRate	eZoomRate;      // 줌배율


        ////////////
        // 내부관리

        // 위치정보
        public bool			bCoordFlag;		// 좌표 단위 플래그, t : DMS, f : Degree
		public List<T_SysPos> listPosData;  // 위치저장 5개
		
		// 조향각
		public bool			angleModeAuto;	// 입력모드, t: 자동입력, f: 수동입력
		public bool			milFlag;		// 각도단위 플래그,  t : MIL, f : Degree

		public T_SimInfo(bool bInit)
		{
			tSysPos = new T_SysPos(true);
			
			nAntAz = 3;
            nAntEl = 0;
            eZoomRate = E_ZoomRate.X3;
            bCoordFlag = true;
            angleModeAuto = true;
            milFlag = true;
			listPosData = new List<T_SysPos>();

			if (bInit == false)
			{
				Console.WriteLine("T_SimInfo 초기화 안함.");
			}
		}

        public void Clear()
        {
			tSysPos = new T_SysPos(true);

            nAntAz = 0;
            nAntEl = 0;
            eZoomRate = E_ZoomRate.X3;
        }
    };


    // 전시 설정
    public struct T_ScopeSetting
    {
        public Scope.E_ScopeDistGap	eDistGap;
        public Scope.E_ScopeAngGap eAngGap;

        public T_ScopeSetting(bool bInit)
        {
            eDistGap	= Scope.E_ScopeDistGap._1000;
            eAngGap		= Scope.E_ScopeAngGap._800;

            if (bInit == false)
            {
                Console.WriteLine("T_ScopeSetting 초기화 안함.");
            }
        }
    };

    #endregion 내부 데이터 구조체 정의
    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// SimSW 데이터 관리 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 26일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class SimSWData
	{
		// SIMSW 내부데이터 선언
		public static T_ConnInfo m_tConnInfo;
		public static T_SimInfo m_tRadarInfo;
		public static T_ScopeSetting m_tPpiScopeSetting;
		public static T_ScopeSetting m_tRhiScopeSetting;

		// 내부 데이터 초기화
		public static void Init()
        {
			m_tConnInfo = new T_ConnInfo(true);
			m_tRadarInfo = new T_SimInfo(true);
			m_tPpiScopeSetting = new T_ScopeSetting(true);
			m_tRhiScopeSetting = new T_ScopeSetting(true);
		}

	}


}
