﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;


//////////////////////////////////////////////
// big endian 변환 필요시 주석 해제
// [프로젝트 속성] - [빌드] - [조건부 컴파일 기호] 에
// _SwapEndian 추가
//////////////////////////////////////////////

// ***** ICD 중요사항 *****
// - TOD에서는 pack을 씌우지 않고 처리한다.
// - 기본 BigEnadian이지만 float형만 예외로 LittleEndian을 사용한다.

namespace ICD
{    
    public class Const
    {
        public const int MSG_SIMSW_INDICATOR            = (0xABCD);
        public const int SIMSRV_ID                      = (0x00);

        // SIMSRV Send (SIMSRV->SIMSW)
        public const int MSG_ID_A_ZOOM_CTRL             = (0xAA02);
        public const int MSG_ID_B_ZOOM_CTRL             = (0xAB02);
        public const int MSG_ID_CONTROLLER_POS_SEARCH   = (0xAC03);
        public const int MSG_ID_STATUS_REQ              = (0xAD01);
        public const int MSG_ID_LOGIN                   = (0xFFAA);
        public const int MSG_ID_TARGET_COORD_CTRL       = (0xAC02);

        // SIMSW Send (SIMSW->SIMSRV)
        public const int MSG_ID_A_ZOOM_CTRL_ACK         = (0xAA02);
        public const int MSG_ID_B_ZOOM_CTRL_ACK         = (0xAB02);
        public const int MSG_ID_PAN_TILT_ACK            = (0xAC02);
        public const int MSG_ID_STATUS_REQ_ACK          = (0xAD01);
        public const int MSG_ID_GPS_DATA_ACK            = (0xAE01);
        public const int MSG_ID_LOGIN_ACK               = (0xFFAA);
    }

    /************************************************************************************/
    /* Message Header Define															*/
    /************************************************************************************/
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_MsgHeader
    {
        public ushort id;         // ID : 0xFEDC
        public byte srcId;        // Message Source ID
        public byte destId;       // Message Destination ID
                                  // SIMSRV : 0x00
                                  // SIMSW : 0x00 ~ 0xFF									
        public ushort msgId;      // Message ID
        public ushort dataSize;	  // Message Size	

        
        public void SwapEndian()
        {
            id = OzNet.Endian.Swap(id);
            msgId = OzNet.Endian.Swap(msgId);
            dataSize = OzNet.Endian.Swap(dataSize);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = string.Format("0x{0:X4} 0x{1:X2} 0x{2:X2} 0x{3:X4} {4:D} ", id, srcId, destId, msgId, dataSize);

            return strLog;
        }
    };


    /************************************************************************************/
    /* SIMSRV Send (SIMSRV->SIMSW)														*/
    /************************************************************************************/

    /****************************************************************************/
    /* A 배율 제어 명령, MSG_ID : 0xAA02										*/
    /****************************************************************************/
    //#define MSG_ID_A_ZOOM_CTRL		(0xAA02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_AZoomCtrl
    {
	    public ICD.ST_MsgHeader msgHeader;
	    public uint zoomRate;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            zoomRate = OzNet.Endian.Swap(zoomRate);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X2}", zoomRate);

            return strLog;
        }
    };

    /****************************************************************************/
    /* B 배율 제어 명령, MSG_ID : 0xAB02										*/
    /****************************************************************************/
    //#define MSG_ID_B_ZOOM_CTRL	(0xAB02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_BZoomCtrl
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint zoomRate;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            zoomRate = OzNet.Endian.Swap(zoomRate);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X2}", zoomRate);

            return strLog;
        }
    };

    /****************************************************************************/
    /* 방향조종기 지점 탐색, MSG_ID : 0xAC03									*/
    /****************************************************************************/
    //#define MSG_ID_CONTROLLER_POS_SEARCH		(0xAC03)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_ControllerPos_Search
    {
	    public ICD.ST_MsgHeader msgHeader;
        public ushort pan;
        public short tilt;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            pan = OzNet.Endian.Swap(pan);
            tilt = OzNet.Endian.Swap(tilt);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("{0:d} {1:d}", pan, tilt);

            return strLog;
        }
    };

    /****************************************************************************/
    /* 상태 요청, MSG_ID : 0xAD01											*/
    /****************************************************************************/
    //#define MSG_ID_STATUS_REQ	(0xAD01)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_StatusReq
    {
	    public ICD.ST_MsgHeader msgHeader;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();

            // 데이터 없음.
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            
            return strLog;
        }
    };

    /****************************************************************************/
    /* 시스템 로그인, MSG_ID : 0xFFAA									*/
    /****************************************************************************/
    //#define MSG_ID_LOGIN		(0xFFAA)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_Login
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint req;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            req = OzNet.Endian.Swap(req);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X1}", req);

            return strLog;
        }
    };

    /****************************************************************************/
    /* 방향조종기 표적좌표 제어, MSG_ID : 0xAC02									*/
    /****************************************************************************/
    // #define MSG_ID_TARGET_COORD_CTRL		(0xAC02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_TargetCoordCtrl
    {
        public ICD.ST_MsgHeader msgHeader;
        [MarshalAs(UnmanagedType.ByValArray, ArraySubType = UnmanagedType.Struct, SizeConst = 16)]
        public byte[] targetMGRS;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();

            // 데이터 없음.
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("{0}", Encoding.Default.GetString(targetMGRS));

            return strLog;
        }
    };


    /************************************************************************************/
    /* SIMSW Send (SIMSW->SIMSRV)														*/
    /************************************************************************************/

    /****************************************************************************/
    /* A 배율 제어 명령 ACK, MSG_ID : 0xAA02									*/
    /****************************************************************************/
    //#define MSG_ID_A_ZOOM_CTRL_ACK		(0xAA02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_AZoomCtrlAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint zoomRate;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            zoomRate = OzNet.Endian.Swap(zoomRate);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X2}", zoomRate);

            return strLog;
        }
    };

    /****************************************************************************/
    /* B 배율 제어 명령 ACK, MSG_ID : 0xAB02									*/
    /****************************************************************************/
    //#define MSG_ID_B_ZOOM_CTRL_ACK	(0xAB02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_BZoomCtrlAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint zoomRate;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            zoomRate = OzNet.Endian.Swap(zoomRate);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X2}", zoomRate);

            return strLog;
        }
    };

    /****************************************************************************/
    /* 방위각고각 ACK, MSG_ID : 0xAC02											*/
    /****************************************************************************/
    //#define MSG_ID_PAN_TILT_ACK	(0xAC02)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_PanTiltAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public ushort pan;
        public short tilt;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            pan = OzNet.Endian.Swap(pan);
            tilt = OzNet.Endian.Swap(tilt);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("{0:d} {1:d}", pan, tilt);

            return strLog;
        }
    };


    /****************************************************************************/
    /* 상태 요청 ACK, MSG_ID : 0xAD01										*/
    /****************************************************************************/
    //#define MSG_ID_STATUS_REQ_ACK	(0xAD01)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_StatusReqAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint status;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            status = OzNet.Endian.Swap(status);            
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X2}", status);

            return strLog;
        }
    };

    /****************************************************************************/
    /* GPS 데이터 ACK, MSG_ID : 0xAE01											*/
    /****************************************************************************/
    //#define MSG_ID_GPS_DATA_ACK	(0xAE01)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_GpsDataAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public float latitude;
        public char indicatorNS;
        public float longitude;
        public char indicatorEW;
        public ushort altitude;    // MSL
        public ushort year;
        public byte month;
        public byte day;
        public byte hour;
        public byte minute;
        public byte second;
        public ushort static1;
        public byte static2;
        public byte static3;
        public byte reserved;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            //latitude = OzNet.Endian.Swap(latitude);
            //longitude = OzNet.Endian.Swap(longitude);
            altitude = OzNet.Endian.Swap(altitude);
            year = OzNet.Endian.Swap(year);
            static1 = OzNet.Endian.Swap(static1);            
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("{0:F8} {1:D} {2:F8} {3:D} {4:D} {5:D} {6:D2} {7:D2} {8:D2} {9:D2} {10:D2} {11:D} {12:D} {13:D}"
                                , latitude, indicatorNS, longitude, indicatorEW, altitude
                                , year, month, day, hour, minute, second
                                , static1, static2, static3);

            return strLog;
        }
    };

    /****************************************************************************/
    /* 시스템 로그인 상태 ACK, MSG_ID : 0xFFAA							*/
    /****************************************************************************/
    //#define MSG_ID_LOGIN_ACK		(0xFFAA)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ST_LoginAck
    {
	    public ICD.ST_MsgHeader msgHeader;
        public uint status;

        public void SwapEndian()
        {
            msgHeader.SwapEndian();
            status = OzNet.Endian.Swap(status);
        }

        public string ToLogString()
        {
            string strLog;

            strLog = msgHeader.ToLogString();
            strLog += string.Format("0x{0:X1}", status);

            return strLog;
        }
    };


}
