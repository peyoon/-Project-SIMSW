﻿using OpenTK.Graphics.OpenGL;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace SIMSW
{
    class LogComm : IDisposable
    {
        private const int LOG_NUM = 65;
        private const int FONT_HEIGHT = 13;

        private GLFont.FontFreeType m_Font;
        private List<string> m_listLog;
        private StreamWriter m_writerLog;

        public bool ShowLog { get; set; }
        public bool PauseLog { get; set; }

        public LogComm()
        {
            ShowLog = false;
            PauseLog = false;

            m_Font = new GLFont.FontFreeType("./Resources/malgun.ttf", 12);
            m_listLog = new List<string>();

            DateTime curTime = DateTime.Now;
            string logfilepath = "./log/Log_" + curTime.ToString("yyyy-MM-dd-HH-mm-ss") + ".txt";

            m_writerLog = File.CreateText(logfilepath);
        }

        ~LogComm()
        {
            Dispose();
        }

        public void Dispose()
        {
            try
            {
                m_writerLog.Close();
                m_writerLog.Dispose();
            }
            catch
            {
                Console.WriteLine("file closed!!");
            }
            
        }

        public void AddLog(byte[] byPacket, bool bRecv)
        {

            lock (m_listLog)
            {
                while (m_listLog.Count > LOG_NUM)
                {
                    m_listLog.RemoveAt(0);
                }
            }

            int nRcvSize = 0;
            int nHeaderSize = Marshal.SizeOf(new ICD.ST_MsgHeader());

            byte[] byHeader = new byte[nHeaderSize];

            ICD.ST_MsgHeader tHeader = new ICD.ST_MsgHeader();

            string strLog;

            if (bRecv)
                strLog = "# ";  // SIMSRV Send
            else
                strLog = "* ";	// SIMSW Send


            DateTime curTime = DateTime.Now;
            strLog += curTime.ToString("yyyyMMddHHmmss ");

            // header
            System.Buffer.BlockCopy(byPacket, 0, byHeader, 0, nHeaderSize);
            tHeader = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_MsgHeader>(byHeader, nHeaderSize);

#if (_SwapEndian)
            tHeader.SwapEndian();
#endif
            //strLog += tHeader.ToLogString();            

            if (bRecv)
            {
                switch (tHeader.msgId)
                {
                    // SIMSRV Send (SIMSRV->SIMSW)
                    case ICD.Const.MSG_ID_A_ZOOM_CTRL:            // = (0xAA02);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_AZoomCtrl());
                            ICD.ST_AZoomCtrl tData = new ICD.ST_AZoomCtrl();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_AZoomCtrl>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();                            
                        }
                        break;

                    case ICD.Const.MSG_ID_B_ZOOM_CTRL:            // = (0xAB02);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_BZoomCtrl());
                            ICD.ST_BZoomCtrl tData = new ICD.ST_BZoomCtrl();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_BZoomCtrl>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();                            
                        }
                        break;

                    case ICD.Const.MSG_ID_CONTROLLER_POS_SEARCH:    // = (0xAC03);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_ControllerPos_Search());
                            ICD.ST_ControllerPos_Search tData = new ICD.ST_ControllerPos_Search();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_ControllerPos_Search>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();                            
                        }
                        break;

                    case ICD.Const.MSG_ID_STATUS_REQ:           // = (0xAD01);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_StatusReq());
                            ICD.ST_StatusReq tData = new ICD.ST_StatusReq();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_StatusReq>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_LOGIN:                // = (0xFFAA);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_Login());
                            ICD.ST_Login tData = new ICD.ST_Login();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_Login>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_TARGET_COORD_CTRL:              //	(0xAC02)
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_TargetCoordCtrl());
                            ICD.ST_TargetCoordCtrl tData = new ICD.ST_TargetCoordCtrl();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_TargetCoordCtrl>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    default:
                        break;
                }
            }
            else
            {
                switch (tHeader.msgId)
                {
                    // SIMSW Send (SIMSW->SIMSRV)
                    case ICD.Const.MSG_ID_A_ZOOM_CTRL_ACK:        // = (0xAA02);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_AZoomCtrlAck());
                            ICD.ST_AZoomCtrlAck tData = new ICD.ST_AZoomCtrlAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_AZoomCtrlAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_B_ZOOM_CTRL_ACK:        // = (0xAB02);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_BZoomCtrlAck());
                            ICD.ST_BZoomCtrlAck tData = new ICD.ST_BZoomCtrlAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_BZoomCtrlAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_PAN_TILT_ACK:             // = (0xAC02);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_PanTiltAck());
                            ICD.ST_PanTiltAck tData = new ICD.ST_PanTiltAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_PanTiltAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_STATUS_REQ_ACK:       // = (0xAD01);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_StatusReqAck());
                            ICD.ST_StatusReqAck tData = new ICD.ST_StatusReqAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_StatusReqAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_GPS_DATA_ACK:             // = (0xAE01);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_GpsDataAck());
                            ICD.ST_GpsDataAck tData = new ICD.ST_GpsDataAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_GpsDataAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    case ICD.Const.MSG_ID_LOGIN_ACK:            // = (0xFFAA);
                        {
                            nRcvSize = Marshal.SizeOf(new ICD.ST_LoginAck());
                            ICD.ST_LoginAck tData = new ICD.ST_LoginAck();
                            tData = OzUtil.MarshalHelper.ByteToStructure<ICD.ST_LoginAck>(byPacket, nRcvSize);

#if (_SwapEndian)
                            tData.SwapEndian();
#endif
                            strLog += tData.ToLogString();
                        }
                        break;

                    default:
                        break;
                }
            }

            // 화면 출력 일시정시시 저장 안함.
            lock (m_listLog)
            { 
                if (PauseLog == false)
                    m_listLog.Add(strLog);
            }

            // 로그 파일 출력
            m_writerLog.WriteLine(strLog);
            m_writerLog.Flush();            
        }

        public void RenderLog(int width, int height)
        {
            if (ShowLog == true)
            {
                while (m_listLog.Count > LOG_NUM)
                {
                    m_listLog.RemoveAt(0);
                }


                GL.MatrixMode(MatrixMode.Projection);
                GL.PushMatrix();
                {
                    GL.LoadIdentity();
                    GL.Viewport(0, 0, width, height);
                    GL.Ortho(0, width, 0, height, 1, -1);
                    
                    GL.MatrixMode(MatrixMode.Modelview);
                    GL.PushMatrix();
                    {
                        GL.LoadIdentity();

                        GL.Color3(1.0f, 1.0f, 0.0f);
                        
                        float x = 10;
                        float y = (float)height - 10.0f;                        
                        
                        x = 10;
                        y = (float)height - 10.0f;
                        y -= FONT_HEIGHT;
                        m_Font.Render(x, y, "[CTRL]");

                        lock (m_listLog)
                        {
                            foreach (var log in m_listLog)
                            {
                                y -= FONT_HEIGHT;

                                GL.Color3(1.0f, 1.0f, 0.0f);
                                m_Font.Render(x, y, log);
                            }
                        }

                    }
                    GL.PopMatrix();
                    GL.MatrixMode(MatrixMode.Projection);
                }
                GL.PopMatrix();
                GL.MatrixMode(MatrixMode.Modelview);


            }



        }


    }
}
            






