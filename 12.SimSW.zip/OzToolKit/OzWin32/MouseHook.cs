﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Interop;

namespace OzWin32
{
    [StructLayout(LayoutKind.Sequential)]
    public struct T_MSLLHOOKSTRUCT
    {
        public T_POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    public enum E_MouseMessages
    {
        WM_MOUSEMOVE = 0x0200,
        WM_LBUTTONDOWN = 0x0201,
        WM_LBUTTONUP = 0X0202,
        WM_MOUSEWHEEL = 0x020A,
        WM_RBUTTONDOWN = 0X0204,
        WM_RBUTTONUP = 0X0205
        //// 기타 마우스 메시지
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 글로벌MouseHook클래스 
    /// <br/> 작 성 자 : 강현우
    /// <br/> 작 성 일 : 2025년 06월 30일
    /// </summary>
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class MouseHook : IDisposable
    {
        private const int WH_MOUSE_LL   = 14;           //  마우스 후크 등록 코드
        
        private IntPtr m_pHookID        = IntPtr.Zero;  // 등록된 후크 ID


        // 마우스 후크메시지 이벤트
        public delegate IntPtr Handler_LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);
        private Handler_LowLevelMouseProc Handle_Proc;

        
        public event EventHandler<MouseHookEventArgs> Event_RMouseClicked;  // 마우스 후크메시지 의 RightClick 이벤트      
        public event EventHandler<MouseHookEventArgs> Event_MouseMoved;     // 마우스 후크메시지 의 MouseMove 이벤트
        public event EventHandler<MouseHookEventArgs> Event_MouseWheel;     // 마우스 후크메시지 의 MouseWheel 이벤트

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 생성자
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public MouseHook()
        {
            Handle_Proc = HookCallback;
            Task.Factory.StartNew(() =>
            {
                m_pHookID = SetHook(Handle_Proc);
                ApplicationMessageLoop();
            }, TaskCreationOptions.LongRunning);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 소멸자
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        ~MouseHook()
        {
            Dispose(false);
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> Mouse의 관리되지 않은 리소스 해제 
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Dispose()
        {
            Dispose(false);
            GC.SuppressFinalize(this);
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> Dispose 호출시 hook 해제 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] disposing - 해제 유무 false 값
        /// <br/> 
        /// <br/> 반 환 값 : 없음
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="disposing"> [in] 해제 유무 false 값 </param>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Dispose(bool disposing=false)
        {
            UnhookWindowsHookEx(m_pHookID);
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 글로벌 mouse hook 등록
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] proc - 특정 메시지 함수 
        /// <br/> 
        /// <br/> 반 환 값 : IntPtr - 등록된 hook handler
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="proc"> [in] 특정 메시지 함수 </param>
        /// <returns> IntPtr - 등록된 hook handler </returns>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private IntPtr SetHook(Handler_LowLevelMouseProc proc)
        {
            IntPtr pHOOKIntptr = IntPtr.Zero;

            using (var curProcess = Process.GetCurrentProcess())
            {
                using (var curModule = curProcess.MainModule)
                {
                    pHOOKIntptr = SetWindowsHookEx(WH_MOUSE_LL, proc, GetModuleHandle(curModule.ModuleName), 0);
                }
            }

            return pHOOKIntptr;
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> hook 호출마다 구현 부 함수         
        /// <br/> 현재 마우스 휠, 마우스 이동 , 마우스오른쪽클릭시 이벤트 호출 구현 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] nCode  - 후크 코드
        /// <br/>       [in] wParam - 메시지 관련정보
        /// <br/>       [in] IParam - 메시지 관련정보
        /// <br/> 
        /// <br/> 반 환 값 : IntPtr - 등록된 hook handler
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="nCode"> [in] 후크 코드 </param>
        /// <param name="wParam"> [in] 메시지 관련정보 </param>
        /// <param name="lParam"> [in] 메시지 관련정보 </param>
        /// <returns> IntPtr - 등록된 hook handler </returns>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            try
            {
                if (nCode >= 0 && E_MouseMessages.WM_MOUSEWHEEL == (E_MouseMessages)wParam)
                {
                    T_MSLLHOOKSTRUCT hookstruct = Marshal.PtrToStructure<T_MSLLHOOKSTRUCT>(lParam);
                    Event_MouseWheel?.Invoke(this, new MouseHookEventArgs(hookstruct.pt.x, hookstruct.pt.y));
                }

                if (nCode >= 0 && E_MouseMessages.WM_MOUSEMOVE == (E_MouseMessages)wParam)
                {
                    T_MSLLHOOKSTRUCT hookstruct = Marshal.PtrToStructure<T_MSLLHOOKSTRUCT>(lParam);
                    Event_MouseMoved?.Invoke(this, new MouseHookEventArgs(hookstruct.pt.x, hookstruct.pt.y));
                }

                if (nCode >= 0 && E_MouseMessages.WM_RBUTTONDOWN == (E_MouseMessages)wParam)
                {
                    T_MSLLHOOKSTRUCT hookstruct = Marshal.PtrToStructure<T_MSLLHOOKSTRUCT>(lParam);
                    Event_RMouseClicked?.Invoke(this, new MouseHookEventArgs(hookstruct.pt.x, hookstruct.pt.y));
                }
            }
            catch (Exception e)
            {

            }
            return CallNextHookEx(m_pHookID, nCode, wParam, lParam);
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 들어온 마우스 후크 메시지를 처리하는 함수 
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ApplicationMessageLoop()
        {
            while (GetMessage(out MSG msg, IntPtr.Zero, 0, 0))
            {
                TranslateMessage(ref msg);
                DispatchMessage(ref msg);
            }
        }

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 들어온 마우스 후크 를 다음 후크 프로시저로 전달하기 위한 함수 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] hhk    - 등록한 후크 코드
        /// <br/>       [in] nCode  - 후크 코드
        /// <br/>       [in] wParam - 메시지 관련정보
        /// <br/>       [in] IParam - 메시지 관련정보
        /// <br/> 
        /// <br/> 반 환 값 : 내부적으로 구현한 받은 메시지 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="hhk"> [in] 등록한 후크 코드 </param>
        /// <param name="nCode">  [in] 후크 코드 </param>
        /// <param name="wParam"> [in] 메시지 관련정보 </param>
        /// <param name="lParam"> [in] 메시지 관련정보 </param>
        /// <returns> 내부적으로 구현한 받은 메시지 반환 </returns>        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 등록된 후크 제거
        /// <br/> <see href="link">https://learn.microsoft.com/ko-kr/windows/win32/api/winuser/nf-winuser-unhookwindowshookex</see>
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] hhk - 등록한 후크
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <returns> 성공 유무 </returns>        
        /// <param name="hhk"> [in] 등록한 후크 </param>
        /// <returns></returns>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 현재 프로세스의 모듈(exe)의 핸들 or dll
        /// <br/> <see href="link">https://learn.microsoft.com/ko-kr/windows/win32/api/libloaderapi/nf-libloaderapi-getmodulehandlea</see>
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] lpModuleName - 현재 exe 프로그램 모듈 이름 
        /// <br/> 
        /// <br/> 반 환 값 : 해당 모듈의 핸들
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <param name="lpModuleName"> [in] 현재 exe 프로그램 모듈 이름  </param>
        /// <returns> 해당 모듈의 핸들 </returns>
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 후크 프로시저 설치
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] idHook - 후크 타입
        /// <br/>       [in] lpfn  - 후크 프로시저
        /// <br/>       [in] hMod - 핸들
        /// <br/>       [in] dwThreadId - 현재 받고 있는 스레드ID 
        /// <br/> 
        /// <br/> 반 환 값 : 해당 모듈의 핸들
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="idHook"> [in] 후크 타입 </param>
        /// <param name="lpfn"> [in] 후크 프로시저 </param>
        /// <param name="hMod"> [in] 핸들 </param>
        /// <param name="dwThreadId"> [in] 현재 받고 있는 스레드ID  </param>
        /// <returns> 해당 모듈의 핸들 </returns>        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, Handler_LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 현재 스레드의 메시지큐에서 메시지 검색
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] lpMsg - 메시지 구조체
        /// <br/>       [in] hWnd  - 윈도우핸들 null 인 경우 모든 메시지
        /// <br/>       [in] wMsgFilterMin - 필터링메시지 최소값
        /// <br/>       [in] wMsgFilterMax - 필터링메시지 최대값 둘다 0 인 경우 모든 메시지를 가져온다.
        /// <br/> 
        /// <br/> 반 환 값 : 1(정상)|0(오류) 
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="lpMsg"> [in] 메시지 구조체 </param>
        /// <param name="hWnd"> [in] 윈도우핸들 null 인 경우 모든 메시지 </param>
        /// <param name="wMsgFilterMin"> [in] 필터링메시지 최소값 </param>
        /// <param name="wMsgFilterMax"> [in] 필터링메시지 최대값 둘다 0 인 경우 모든 메시지를 가져온다. </param>
        /// <returns>1(정상)|0(오류) </returns>        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool GetMessage(out MSG lpMsg, IntPtr hWnd, uint wMsgFilterMin, uint wMsgFilterMax);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 메시지를 변환
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] lpMsg - 메시지 구조체
        /// <br/> 
        /// <br/> 반 환 값 : 해당 모듈의 핸들
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <param name="lpMsg"> [in] 메시지 구조체 </param>
        /// <returns>해당 모듈의 핸들</returns>        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern bool TranslateMessage(ref MSG lpMsg);


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 메시지를 윈도우 핸들에게 전달
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] lpMsg - 메시지 구조체
        /// <br/> 
        /// <br/> 반 환 값 : 해당 모듈의 핸들
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <param name="lpMsg"> [in] 메시지 구조체 </param>
        /// <returns>해당 모듈의 핸들</returns>        
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr DispatchMessage(ref MSG lpMsg);
    }

    public class MouseHookEventArgs : EventArgs
    {
        public T_POINT  tPoint;

        public int      nX { get; private set; }
        public int      nY { get; private set; }

        public int      nLocal_X { get; private set; }
        public int      nLocal_Y { get; private set; }

        public bool     bLEFTBtnPress { get; private set; }

        public bool     bRIGHTBtnPress { get; private set; }

        public MouseHookEventArgs(int x, int y)
        {
            nX = x;
            nY = y;

            tPoint = new T_POINT();
            tPoint.x = x; tPoint.y = y;
        }
                

        public MouseHookEventArgs Clone()
        {
            MouseHookEventArgs new_mousehookpoint = new MouseHookEventArgs(nX, nY);
            return new_mousehookpoint;
        }

        /// <summary>
        /// <br/> 디스플레이 배율에 따른 마우스 포인터 좌표 변경 함수 
        /// <br/> 파라미터 : [in] dDpi - 화면 배율에따른 현재 마우스 포인터의 좌표 변경 
        /// </summary>
        /// <param name="dDpi"></param>
        public void DpiScale(double dDpi)
        {
            nX = nLocal_X = Convert.ToInt32(nX / dDpi);
            nY = nLocal_Y = Convert.ToInt32(nY / dDpi);
        }
    }
}
