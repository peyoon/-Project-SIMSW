﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace OzWin32
{
    [StructLayout(LayoutKind.Sequential)]
    public struct T_POINT
    {
        public int x;
        public int y;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> System DLL 함수 클래스 - 윈도우 창 관련 함수 모음.(Win32DLL_Windows.cs)
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    ///
    public partial class Win32DLL
    {

        #region 절전모드 진입 방지


        [FlagsAttribute]
        private enum EXECUTION_STATE : uint
        {
            ES_AWAYMODE_REQUIRED = 0x00000040,
            ES_CONTINUOUS = 0x80000000,
            ES_DISPLAY_REQUIRED = 0x00000002,
            ES_SYSTEM_REQUIRED = 0x00000001
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern EXECUTION_STATE SetThreadExecutionState(EXECUTION_STATE exFlags);

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 프로그램 운용 중 화면 슬림 방지 (스크린세이버, 절전모드)
        /// <br/> 
        /// <br/> 파라미터 : -  
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>    
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static void PreventScreenAndSleep()
        {
            try
            {
                SetThreadExecutionState(EXECUTION_STATE.ES_CONTINUOUS |
                       EXECUTION_STATE.ES_SYSTEM_REQUIRED |
                       EXECUTION_STATE.ES_DISPLAY_REQUIRED |
                       EXECUTION_STATE.ES_AWAYMODE_REQUIRED);
                int errCode = Marshal.GetLastWin32Error();
                if (errCode != 0)
                {
                    System.Console.WriteLine(string.Format("{0}", new System.ComponentModel.Win32Exception(errCode).Message));
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex);
            }
        }

        #endregion 절전모드 진입 방지



        #region 윈도우 창 컨트롤

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> Main thread 미응답시 응답대기로 넘어가는 현상 방지를 위한 off win32 class 함수 
        /// <br/> 
        /// <br/> 파라미터 :  -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>                
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern void DisableProcessWindowsGhosting();


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 현재 포커스 되어 있는 Window 가져오기
        /// <br/> 
        /// <br/> 파라미터 :  -
        /// <br/> 
        /// <br/> 반 환 값 : 윈도우 핸들 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>     
        /// <returns> 윈도우 핸들 반환 </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("User32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern IntPtr GetActiveWindow();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 현재 마우스 포인터 가져오기
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [out] tPoint - 현재 마우스 포인터 정보 현재 모니터의 사이즈를 기반으로 반환
        /// <br/> 
        /// <br/> 반 환 값 : 성공유무
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <param name="tPoint"> 현재 마우스 포인터 정보 현재 모니터의 사이즈를 기반으로 반환 </param>
        /// <returns> 성공유무 </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("User32.dll")]
        public static extern bool GetCursorPos(out T_POINT tPoint);


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 현재 마우스 밑에서 가장 위에있는 window_handel를 가져 옵니다
        /// <example><code>
        ///     T_POINT t_point = new T_POINT();
        ///     GetCursorPos(out t_point);
        ///     WindowFromPoint(t_point);
        /// </code></example>
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] tPoint - 현재 마우스 포인터 정보 현재 모니터의 사이즈를 기반
        /// <br/> 
        /// <br/> 반 환 값 : 윈도우 핸들 반환
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일        
        /// </summary>
        /// <param name="tPoint"> 현재 마우스 포인터 정보 현재 모니터의 사이즈를 기반 </param>
        /// <returns> 윈도우 핸들 반환 </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll")]
        public static extern IntPtr WindowFromPoint(T_POINT tPoint);

       
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 지정한 윈도우 핸들의 생성스레드와 프로세스 ID 를 가져오는 함수
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] hWnd               - 윈도우 핸들
        /// <br/>       [out] lpdwProcessId     - 프로세스 핸들 프로세스 식별자를 수신하는 변수에 대한 포인터 
        /// <br/> 
        /// <br/> 반 환 값 : 스레드 ID , 실패시 0
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /// <param name="hWnd"> [in] 윈도우 핸들 </param>
        /// <param name="lpdwProcessId"> [out] 프로세스 핸들 프로세스 식별자를 수신하는 변수에 대한 포인터  </param>
        /// <returns> 스레드 ID , 실패시 0</returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("user32.dll")]
        public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        #endregion 윈도우 창 컨트롤


    }
}
