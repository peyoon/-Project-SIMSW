﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzNet
{

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> Serial 통신 클래스 RS232, RS422 
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public class SerialComm
    {
        private const int   MAX_BUFFER      = 4096;         // 최대 버퍼 사이즈 - 시리얼 장치의 버퍼에 따라 설정

        private SerialPort  m_Serial        = null;         // 시리얼 포트        
        private bool        m_IsOpen        = false;        // 시리얼 포트 Open 여부


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 생성자
        /// <br/> 파라미터 : -
        /// <br/> 반 환 값 : -
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public SerialComm()
        {
            m_Serial = null;         // 시리얼 포트        
            m_IsOpen = false;        // 시리얼 포트 Open 여부
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> Serial Port 열기
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] strPortName -  Serial Port 명 (ex: COM1)
        /// <br/>       [in] nBaudRate   -  Serial Baud Rate (ex: 9800)
        /// <br/>       [in] parity      -  패리티 비트 (default: None)
        /// <br/>       [in] nDataBit    -  데이터 비트 (default: 8)
        /// <br/>       [in] stopbit     -  Stop 비트 (default: One)
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="strPortName">  [in] Serial Port 명 (ex: COM1)    </param>
        /// <param name="nBaudRate">    [in] Serial Baud Rate (ex: 9800)  </param>
        /// <param name="parity">       [in] 패리티 비트 (default: None)  </param>
        /// <param name="nDataBit">     [in] 데이터 비트 (default: 8)     </param>
        /// <param name="stopbit">      [in] Stop 비트 (default: One)      </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void OpenPort(string strPortName, int nBaudRate, Parity parity = Parity.None, int nDataBit = 8, StopBits stopbit = StopBits.One)
        {
            try
            {
                m_Serial = new SerialPort(strPortName, nBaudRate, parity, nDataBit, stopbit);

                m_Serial.Handshake = Handshake.None;
                //m_Serial.ReadTimeout = 50;
                //m_Serial.WriteTimeout = 50;
                m_Serial.ReadBufferSize = MAX_BUFFER;
                m_Serial.WriteBufferSize = MAX_BUFFER;                

                m_Serial.Open();

                m_IsOpen = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);

                m_IsOpen = false;
            }
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> Serial Port 닫기(종료)
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ClosePort()
        {
            if (m_IsOpen == true)
            {
                m_Serial.Close();
                m_Serial.Dispose();
            }

            m_IsOpen = false;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 시리얼 포트 Open 여부
        /// <br/> 
        /// <br/> 파라미터 : -
        /// <br/> 
        /// <br/> 반 환 값 : t-Open, f-Close
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>
        /// <returns>   t-Open, f-Close    </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool IsOpen()
        {
            return m_IsOpen;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 데이터 송신
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] bySendData  -  송신 데이터 버퍼        
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="bySendData">   [in] 송신 데이터 버퍼   </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void Send(byte[] bySendData)
        {
            try
            {
                //시리얼 포트가 열려있으면
                if (m_IsOpen == true)
                {
                    m_Serial.Write(bySendData, 0, bySendData.Length);
                }
            }
            catch (Exception ex)
            {
                ClosePort();

                Console.WriteLine(ex);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수신된 전체 데이터 얻기 - 스레드를 통해 상시 데이터 수신확인
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [out] byReciveData    -  데이터 수신 저장 버퍼
        /// <br/> 
        /// <br/> 반 환 값 : 수신된 데이터 사이즈
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 05월 14일
        /// </summary>        
        /// <param name="byReciveData"> [out] 데이터 수신 저장 버퍼   </param>
        /// <returns>   수신된 데이터 사이즈 </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public int Receive(ref byte[] byReciveData)
        {
            int nReceiveSize = 0;       //수신된 데이터 사이즈

            try
            {
                //시리얼 포트가 열려있으면
                if (m_IsOpen == true)
                {
                    // 수신된 버퍼 사이즈 얻기
                    int nBufferSize = m_Serial.BytesToRead;

                    // 수신된 데이터가 있으면..
                    if (nBufferSize > 0)
                    {
                        // 최대 수신 사이즈 보다 크면 최대 수신 사이즈만 처리
                        if (nBufferSize >= MAX_BUFFER)
                            nBufferSize = MAX_BUFFER;

                        nReceiveSize = m_Serial.Read(byReciveData, 0, nBufferSize);
                    }
                }
            }
            catch (Exception ex)
            {
                ClosePort();

                Console.WriteLine(ex);
            }

            return nReceiveSize;
        }
    }
}
