﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzMethodEx
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 자료형 확장 클래스 - float, double
    /// <br/> using OzMethodEx 선언으로 사용
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 07월 29일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public static class MethodEx_Float
    {
        #region float 확장 메소드

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 부동소수점 오차 범위내에 값이 같은지 결과를 반환
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] fCur       - 현재 값 (this)
        /// <br/>       [in] fComp      - 비교 대상 값
        /// <br/>       [in] fEpsilon   - 부동소수점 오차 범위 (default: 1e-5f)
        /// <br/> 
        /// <br/> 반 환 값 : true - 같음, false - 다름
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 07월 29일
        /// </summary>  
        /// <param name="fCur">     [in] 현재 값 (this)   </param>
        /// <param name="fComp">    [in] 비교 대상 값       </param>
        /// <param name="fEpsilon"> [in] 부동소수점 오차 범위 (default: 1e-5f)  </param>
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static bool ozEquals(this float fCur, float fComp, float fEpsilon = 1e-5f)
        {
            return Math.Abs(fCur - fComp) < fEpsilon;
        }




        #endregion float 확장 메소드



        #region double 확장 메소드

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 부동소수점 오차 범위내에 값이 같은지 결과를 반환
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] dCur       - 현재 값 (this)
        /// <br/>       [in] dComp      - 비교 대상 값
        /// <br/>       [in] dEpsilon   - 부동소수점 오차 범위 (default: 1e-10)
        /// <br/> 
        /// <br/> 반 환 값 : true - 같음, false - 다름
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 07월 29일
        /// </summary>
        /// <param name="dCur">     [in] 현재 값 (this)  </param>
        /// <param name="dComp">    [in] 비교 대상 값   </param>
        /// <param name="dEpsilon"> [in] 부동소수점 오차 범위 (default: 1e-10)  </param>
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static bool ozEquals(this double dCur, double dComp, double dEpsilon = 1e-10)
        {
            return Math.Abs(dCur - dComp) < dEpsilon;
        }




        #endregion double 확장 메소드
    }
}
