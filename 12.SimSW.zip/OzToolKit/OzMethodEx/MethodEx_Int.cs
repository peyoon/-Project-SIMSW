﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace OzMethodEx
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> 자료형 확장 클래스 - int, short
    /// <br/> using OzMethodEx 선언으로 사용
    /// <br/> 작 성 자 : 장봉석
    /// <br/> 작 성 일 : 2025년 07월 28일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public static class MethodEx_Int
    {
        #region short 확장 메소드

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 짝수 여부 반환
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] nValue     - 현재 값  (this)
        /// <br/> 
        /// <br/> 반 환 값 : true - 짝수, false - 홀수
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 07월 29일
        /// <param name="sValue">       [in] 현재 값       </param>
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static bool ozIsEven(this short sValue)
        {
            return sValue % 2 == 0;
        }




        #endregion short 확장 메소드



        #region int 확장 메소드

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 짝수 여부 반환
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] nValue     - 현재 값 (this)
        /// <br/> 
        /// <br/> 반 환 값 : true - 짝수, false - 홀수
        /// <br/> 
        /// <br/> 작 성 자 : 장봉석
        /// <br/> 작 성 일 : 2025년 07월 29일
        /// </summary>  
        /// <param name="nValue">       [in] 현재 값 (this)       </param>
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public static bool ozIsEven(this int nValue)
        {
            return nValue % 2 == 0;
        }


        #endregion int 확장 메소드


    }
}
