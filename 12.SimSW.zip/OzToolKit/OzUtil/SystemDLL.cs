﻿using System;
using System.Runtime.InteropServices;
using System.Text;

namespace OzUtil
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// System DLL 함수 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 05월 14일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    public class SystemDLL
    {

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		#region INI 파일 처리

		[DllImport("kernel32")]
		public static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal,
														int size, string filePath);

		[DllImport("kernel32")]
		public static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

        #endregion INI 파일 처리		
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        #region DLL 파일 처리

        [DllImport("kernel32.dll", EntryPoint = "LoadLibrary")]
        public extern static IntPtr LoadLibrary(string librayName);

        [DllImport("kernel32.dll", EntryPoint = "GetProcAddress", CharSet = CharSet.Ansi)]
        public extern static IntPtr GetProcAddress(IntPtr hwnd, string procedureName);

        [DllImport("kernel32.dll", EntryPoint = "FreeLibrary")]
        public extern static bool FreeLibrary(IntPtr hModule);

        [DllImport("kernel32")]
        public static extern IntPtr GetModuleHandle(string librayName);

        #endregion DLL 파일 처리


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 프로그램 운용 중 절전모드 진입 방지
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 05월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern EXECUTION_STATE SetThreadExecutionState(EXECUTION_STATE exFlags);
        [FlagsAttribute]
        public enum EXECUTION_STATE : uint
        {
            ES_AWAYMODE_REQUIRED = 0x00000040,
            ES_CONTINUOUS = 0x80000000,
            ES_DISPLAY_REQUIRED = 0x00000002,
            ES_SYSTEM_REQUIRED = 0x00000001
        }

        public static void PreventScreenAndSleep()
        {
            try
            {
                SetThreadExecutionState(EXECUTION_STATE.ES_CONTINUOUS |
                       EXECUTION_STATE.ES_SYSTEM_REQUIRED |
                       EXECUTION_STATE.ES_DISPLAY_REQUIRED |
                       EXECUTION_STATE.ES_AWAYMODE_REQUIRED);
                int errCode = Marshal.GetLastWin32Error();
                if (errCode != 0)
                {
                    System.Console.WriteLine(string.Format("{0}", new System.ComponentModel.Win32Exception(errCode).Message));
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(ex);
            }
        }



    }
}
