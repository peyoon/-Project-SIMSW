﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OzUtil
{
    public enum E_RegistryField
    {
        None = 1,
        CurrentUser = 2,
        CurrentConfig = 4,
        LocalMachine = 8,
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 레지스터 용 클래스
    /// 작 성 자 : 강현우
    /// 작 성 일 : 2025년 07월 01일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class RegistryModel
    {
        private readonly string m_key;
        private readonly string m_subkey;

        public string GetKeyName
        {
            get
            {
                return $"{m_key}{m_subkey}";
            }
        }

        public RegistryModel(string key,string subkey)
        {
            this.m_key = key;
            this.m_subkey = subkey;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레지스터 서브키 키읽기 | LocalMachine 인 경우가 구현 필요시 더 구현 필요 
        /// 파라미터 : [in] eRegfiled  - 레지스터에서 찾기위한 열겨형 Command
        ///            [in] subpath   - 레지스터 루트키의 하위 경로 공백인 경우 생성자의 sub키가 들어감 
        /// 반 환 값 : subpath의 하위 폴더 항목들 | 없거나 찾이못하면 0개 의 List 클래스 반환
        /// 작 성 자 : 강현우
        /// 작 성 일 : 2025년 07월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public List<string> GetSubKeyNames(E_RegistryField eRegfiled , string subpath)
        {
            List<string> result = new List<string>();

            if (string.IsNullOrEmpty(subpath))
            {
                switch (eRegfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey($"{m_subkey}");
                        if (key != null)
                        {
                            foreach (var subkeyname in key.GetSubKeyNames())
                            {
                                result.Add(subkeyname);
                            }

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }

            }
            else
            {
                switch (eRegfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey($"{subpath}");
                        if (key != null)
                        {
                            foreach(var subkeyname in key.GetSubKeyNames())
                            {
                                result.Add(subkeyname);
                            }

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }
            }
            
            return result;
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레지스터 서브키 값이름  | LocalMachine 인 경우가 구현 필요시 더 구현 필요 
        /// 파라미터 : [in] eRegfiled  - 레지스터에서 찾기위한 열겨형 Command
        ///            [in] subpath   - 레지스터 루트키의 하위 경로 공백인 경우 생성자의 sub키가 들어감 
        /// 반 환 값 : subpath의 하위 폴더 의 값항목들 | 없거나 찾이못하면 0개 의 List 클래스 반환
        /// 작 성 자 : 강현우
        /// 작 성 일 : 2025년 07월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public List<string> GetValueNames(E_RegistryField regfiled, string subpath)
        {
            List<string> result = new List<string>();

            if (string.IsNullOrEmpty(subpath))
            {
                switch (regfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey($"{m_subkey}");
                        if (key != null)
                        {
                            foreach (var subkeyname in key.GetValueNames())
                            {
                                result.Add(subkeyname);
                            }

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }

            }
            else
            {
                switch (regfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey($"{subpath}");
                        if (key != null)
                        {
                            foreach (var subkeyname in key.GetValueNames())
                            {
                                result.Add(subkeyname);
                            }

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }
            }

            return result;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레지스터 서브키 값 | LocalMachine 인 경우가 구현 필요시 더 구현 필요 
        /// 파라미터 : [in] eRegfiled  - 레지스터에서 찾기위한 열겨형 Command
        ///            [in] subpath   - 레지스터 루트키의 하위 경로 공백인 경우 생성자의 sub키가 들어감 
        ///            [in] value     - 레지스터 루트키의 하위 경로 값을 읽기위한 value 이름 
        /// 반 환 값 : object  | 없는경우 "NotFindValueName" string 값 반환 
        /// 작 성 자 : 강현우
        /// 작 성 일 : 2025년 07월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public object GetValue(E_RegistryField regfiled, string subpath, string valuename)
        {
            object result = string.Empty;

            if (string.IsNullOrEmpty(subpath))
            {
                switch (regfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey(m_subkey);
                        if (key != null)
                        {
                            result = key.GetValue(valuename, "NotFindValueName");

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }

            }
            else
            {
                switch (regfiled)
                {
                    case E_RegistryField.CurrentUser:
                        break;
                    case E_RegistryField.CurrentConfig:
                        break;
                    case E_RegistryField.LocalMachine:
                        RegistryKey key = Registry.LocalMachine.OpenSubKey(subpath);
                        if (key != null)
                        {
                            result = key.GetValue(valuename, "NotFindValueName");

                            key.Close();
                        }
                        break;
                    default:
                        break;
                }
            }

            return result;
        }


    }
}
