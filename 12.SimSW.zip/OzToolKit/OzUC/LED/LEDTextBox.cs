﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace OzUC
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// LED 효과 적용 TextBox 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2025년 06월 30일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class LEDTextBox : TextBox
    {
        private bool            m_bDetectChangeValue;   // 값 변경에 따른 애니매이션 사용 유무
        private string          m_strPrevText;          // 이전 설정값. - 바뀌면 LED 동작

        private Storyboard      m_storyboard;           // 깜빡임 애니매이션 story
        private ColorAnimation  m_animation;            // 깜빡임 애니매이션

        private Color           m_OnFrom;               // 시작 컬러
        private Color           m_OnTo;                 // 끝 컬러


        // 값 변경 감지 사용 유무 - 감지시 애니매이션 동작
        public bool IsDetectChangeValue
        {
            get
            {
                return m_bDetectChangeValue;
            }

            set
            {
                m_bDetectChangeValue = value;
            }
        }

        // 애니매이션 속도 설정 - 시간[s] (ex: 0:0:1)
        // ex) AnimateDuration 0:0:1 설정시 
        // To 까지 1초, 다시 From까지 1초 동작
        public Duration AnimateDuration
        {
            set
            {
                m_animation.Duration = value;
            }
        }

        // 애니메이션 동작 시간 - 시간[s] (ex: 0:0:4)
        // ex1) AnimateDuration == 0:0:1일 때 1회 깜빡임을 구현할 때는 AnimateRepeatBehavior=0:0:2로 설정
        //      To까지 1초, 다시 From까지 1초 원상태까지 2초 걸림        
        // ex2) AnimateDuration=0:0:1일 때 AnimateRepeatBehavior=0:0:4 => 2회 깜빡임
        // 무한: Forever => AnimationStop()이 호출때까지 반복동작
        public RepeatBehavior AnimateRepeatBehavior
        {
            set
            {
                m_animation.RepeatBehavior = value;
            }
        }


        ////////////////////
        // 색상 설정

        // 시작 컬러 설정
        public Color OnFrom
        {
            set
            {
                m_OnFrom = value;
                this.Background = new SolidColorBrush(m_OnFrom);

                m_animation.From = m_OnFrom;
            }
        }

        // 끝 컬러 설정
        public Color OnTo
        {
            set
            {
                m_OnTo = value;

                m_animation.To = m_OnTo;
            }
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 생성자
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public LEDTextBox() : base()
        {
            // 이전 설정값 - 바뀌면 LED 동작
            m_strPrevText = this.Text;

            // 변경 이벤트
            this.TextChanged += TextChanged_this;

            // 값 변경에 따른 애니매이션 사용 유무
            m_bDetectChangeValue = true;
            
            // 테마 컬러 적용
            SolidColorBrush brushDefault = Application.Current.Resources["ABrush.TextBox.ReadOnly"] as SolidColorBrush;

            m_OnTo = Colors.Yellow;
            m_OnFrom = brushDefault.Color;

            // LED Stroryboard 적용
            m_storyboard = new Storyboard();
            m_animation = new ColorAnimation();
            m_animation.Duration = new Duration(TimeSpan.FromSeconds(1));
            m_animation.AutoReverse = true;
            m_animation.RepeatBehavior = new RepeatBehavior(4);
            m_animation.To = m_OnTo;
            m_animation.From = m_OnFrom;
            Storyboard.SetTarget(m_animation, this);
            Storyboard.SetTargetProperty(m_animation, new PropertyPath("Background.(SolidColorBrush.Color)"));
            m_storyboard.Children.Add(m_animation);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// LED(애니매이션) 동작 시작
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void AnimationBegin()
        {
            m_storyboard.Begin();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// LED(애니매이션) 동작 종료
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void AnimationStop()
        {
            m_storyboard.Stop();
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// TexBox Value 변경 이벤트 처리
        /// 파라미터 : -
        /// 반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void TextChanged_this(object sender, TextChangedEventArgs e)
        {
            // 이전 값과 틀리면 LED 작동
            if (m_strPrevText != this.Text)
            {
                if (IsDetectChangeValue == true)
                {
                    m_storyboard.Begin();
                }
            }

            m_strPrevText = this.Text;
        }


    }

}
