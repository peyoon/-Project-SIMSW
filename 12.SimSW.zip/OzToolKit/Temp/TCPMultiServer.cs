﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace OzNet
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// <br/> TCP 통신 클래스 - 수신받은 Socket 새로운 task 를 만드는 방식의 TCP 서버 클래스 
    /// <br/> 작 성 자 : 강현우
    /// <br/> 작 성 일 : 2025년 06월 30일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public class TCPMultiServer
    {
        private Socket  m_socket;           // TCP 서버 Socket
        private bool    m_isServerStart;    // TCP 서버 작동 유무

        // 연결된 클라이언트 
        private Dictionary<string, Tuple<Task, CancellationTokenSource, Socket>> m_RemoteControl;


        private CancellationTokenSource m_servercanceltoken;        // 서버시작시 종료를 위한 토큰 

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> socket 연결후 수신 이벤트 위한 Eventhandler
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public event EventHandler<RxEventArgs> Event_Rxmessage;

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> socket 연결후 연결 이벤트 위한 Eventhandler
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public event EventHandler<ConnectEventArgs> Event_connect;

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> socket 연결후 연결 종료 및 끊김 이벤트 위한 Eventhandler
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public event EventHandler<ConnectEventArgs> Event_disconnect;


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 생성자
        /// <br/> 반 환 값 : -
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public TCPMultiServer()
        {
            m_isServerStart = false;
            m_RemoteControl = new Dictionary<string, Tuple<Task, CancellationTokenSource, Socket>>();
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> socket 연결 대기를 위한 함수
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>       [in] IP      -  host IP
        /// <br/>       [in] Port    -  host Port
        /// <br/>       [in] headbuffer -  패킷 headbuffersize
        /// <br/>       [in] Buffersize -  수신버퍼사이즈 8kbyte
        /// <br/>       [in] SendBuffersize - 송신버퍼사이즈 8kbyte
        /// <br/>       [in] accpetsize - 연결대기자 수
        /// <br/>
        /// <br/> 반 환 값 : ( 연결 대기 성공 유무, 수신대기 task, 오류시 오류메시지 ) 
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="IP">               [in] host IP        </param>
        /// <param name="Port">             [in] host Port      </param>
        /// <param name="headbuffer">       [in] 패킷 headbuffersize    </param>
        /// <param name="Buffersize">       [in] 수신버퍼사이즈 8kbyte   </param>
        /// <param name="SendBuffersize">   [in] 송신버퍼사이즈 8kbyte    </param>
        /// <param name="accpetsize">       [in] 연결대기자 수   </param>
        /// <returns>  ( 연결 대기 성공 유무, 수신대기 task, 오류시 오류메시지 )   </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public Tuple<bool, Task, string> StartListen(IPAddress IP, int Port, byte[] headbuffer, int Buffersize = 8192, int SendBuffersize = 8192, int accpetsize = 10)
        {

            bool flag = false;
            Task task = null;
            string message = string.Empty;
            try
            {
                if (m_isServerStart == true)
                {

                }
                else
                {
                    task = ServerStart(IP, Port, headbuffer, Buffersize, SendBuffersize, accpetsize);
                }
                flag = true;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                flag = false;
            }
            finally
            {

            }

            return new Tuple<bool, Task, string>(flag, task, message);
        }


        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 서버측에서 특정 클라이언트에게 송신용 함수
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>   [in] IPEndPoint  - 클라이언트 IPEndPoint 정보
        /// <br/>   [in] msg         - 송신 bytes 메시지
        /// <br/>
        /// <br/> 반 환 값 : -
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void SendIpendPoint(IPEndPoint ipEndPoint, byte[] msg)
        {
            try
            {
                var addressPoint = $"{ipEndPoint.Address.ToString()}:{ipEndPoint.Port.ToString("D6")}";

                if (m_RemoteControl.ContainsKey(addressPoint))
                {
                    var find_item = m_RemoteControl[addressPoint];
                    find_item.Item3.Send(msg, SocketFlags.None);
                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수신 받은 메시지 에대한 반환용 함수
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] client  - 클라이언트 IPEndPoint 정보
        /// <br/>       [in] msg     - 송신 bytes 메시지
        /// <br/> 
        /// <br/> 반 환 값 : bool 송신 성공 유무 반환 
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일        
        /// </summary>        
        /// <param name="client">   [in] 클라이언트 IPEndPoint 정보  </param>
        /// <param name="msg">      [in] 송신 bytes 메시지 </param>
        /// <returns>   bool 송신 성공 유무 반환    </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public bool SendMessage(Socket client, byte[] msg)
        {
            bool sendflag = false;
            try
            {
                client.Send(msg, SocketFlags.None);
                sendflag = true;
            }
            catch (Exception ex)
            {
                sendflag = false;
            }

            return sendflag;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 서버 종료
        /// <br/> 파라미터 : -
        /// <br/> 반 환 값 : -
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일        
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void ServerStop()
        {
            m_isServerStart = false;

            try
            {
                m_servercanceltoken.Cancel();
                m_servercanceltoken.Dispose();
            }
            catch
            {

            }

            try
            {
                foreach (var remotesocket in m_RemoteControl.Values)
                {
                    Socket closesocket = remotesocket.Item3;
                    try
                    {
                        closesocket.Shutdown(SocketShutdown.Both);
                        closesocket.Close();
                        closesocket.Dispose();
                    }
                    catch (Exception ex)
                    {
                        if (ex is SocketException)
                        {
                            var socketex = ex as SocketException;
                            switch (socketex.SocketErrorCode)
                            {
                                case SocketError.NotConnected:
                                    closesocket.Close();
                                    closesocket.Dispose();
                                    break;
                            }
                        }
                        if (ex is ObjectDisposedException)
                        {

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                m_RemoteControl.Clear();
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> m_RemoteControl 멤버변수에 추가 원격 point 존재시 삭제 후 추가 
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>       [in] client - 클라이언트 추가
        /// <br/>       [in] cts    - 수신 task의 token source
        /// <br/>       [in] task   - 수신 task
        /// <br/>
        /// <br/> 반 환 값 : -
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일        
        /// </summary>        
        /// <param name="client">   [in] 클라이언트 추가  </param>
        /// <param name="cts">      [in] 수신 task의 token source </param>
        /// <param name="task">     [in] 수신 task   </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ClientAddSocket(Socket client, CancellationTokenSource cts, Task task)
        {
            try
            {
                var cloneEndPoint = client.RemoteEndPoint;
                var socketaddress = cloneEndPoint.Serialize();
                var IP_PORT = (IPEndPoint)client.RemoteEndPoint.Create(socketaddress);
                var addressPoint = $"{IP_PORT.Address.ToString()}:{IP_PORT.Port.ToString("D6")}";
                if (m_RemoteControl.ContainsKey(addressPoint))
                {
                    ClientRemoveSocket(client);
                    m_RemoteControl.Add(addressPoint, new Tuple<Task, CancellationTokenSource, Socket>(task, cts, client));
                }
                else
                {
                    m_RemoteControl.Add(addressPoint, new Tuple<Task, CancellationTokenSource, Socket>(task, cts, client));
                }
            }
            catch (Exception ex)
            {
                switch (ex)
                {
                    case ObjectDisposedException objectDisposedException:
                        break;
                }
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> m_RemoteControl 멤버변수에 삭제        
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>       [in] client - 클라이언트 추가
        /// <br/>
        /// <br/> 반 환 값 : -
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 27일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ClientRemoveSocket(Socket client)
        {
            try
            {
                var cloneEndPoint = client.RemoteEndPoint;
                var socketaddress = cloneEndPoint.Serialize();
                var IP_PORT = (IPEndPoint)client.RemoteEndPoint.Create(socketaddress);
                var addressPoint = $"{IP_PORT.Address.ToString()}:{IP_PORT.Port.ToString("D6")}";
                if (m_RemoteControl.ContainsKey(addressPoint))
                {
                    var ItemValue = m_RemoteControl[addressPoint];
                    ItemValue.Item2.Cancel();

                    try
                    {
                        ItemValue.Item3.Shutdown(SocketShutdown.Both);
                        ItemValue.Item3.Close();
                        ItemValue.Item3.Dispose();
                    }
                    catch
                    {

                    }
                }
                else
                {

                }
            }
            catch (Exception ex)
            {
                switch (ex)
                {
                    case ObjectDisposedException objectDisposedException:
                        break;
                }
            }

        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수신대기 서버 시작
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>       [in] IP             -  IP Address
        /// <br/>       [in] Port           -  Port
        /// <br/>       [in] headbuffer     -  패킷 headbuffersize
        /// <br/>       [in] Buffersize     -  수신버퍼사이즈 8kbyte
        /// <br/>       [in] SendBuffersize - 송신버퍼사이즈 8kbyte
        /// <br/>       [in] accpetsize     - 연결대기자 수
        /// <br/>
        /// <br/> 반 환 값 : Task 수신 대기 서버 시작 task 
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="IP">               [in] IP Address             </param>
        /// <param name="Port">             [in] Port                   </param>
        /// <param name="headbuffer">       [in] 패킷 headbuffersize    </param>
        /// <param name="Buffersize">       [in] 수신버퍼사이즈 8kbyte  </param>
        /// <param name="SendBuffersize">   [in] 송신버퍼사이즈 8kbyte  </param>
        /// <param name="accpetsize">       [in] 연결대기자 수          </param>
        /// <returns>   Task 수신 대기 서버 시작 task   </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private Task ServerStart(IPAddress IP, int Port, byte[] headbuffer, int Buffersize = 8192, int SendBuffersize = 8192, int accpetsize = 10)
        {
            m_servercanceltoken = new CancellationTokenSource();
            var canceltoken = m_servercanceltoken.Token;
            var servertask = Task.Factory.StartNew(() =>
            {
                var ep = new IPEndPoint(IP, Port);
                m_socket = new Socket(ep.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
                m_socket.ReceiveBufferSize = Buffersize;
                m_socket.SendBufferSize = SendBuffersize;
                m_socket.Bind(ep);
                m_socket.Listen(accpetsize);
                m_isServerStart = true;

                while (true)
                {
                    var client = m_socket.Accept();
                    ProcEvent_ConnectEvent(client, true);
                    var servertoken = m_servercanceltoken.Token;

                    CancellationTokenSource cts = new CancellationTokenSource();
                    var tasktoken = cts.Token;
                    var rxtask = Task.Factory.StartNew(() =>
                    {
                        InitSocket(client);
                        StartServer(client, headbuffer, tasktoken);
                        ProcEvent_DisConnectEvent(client, false);
                    }, servertoken);

                    ClientAddSocket(client, cts, rxtask);

                    if (m_isServerStart == false)
                    {
                        break;
                    }
                    if (canceltoken.IsCancellationRequested)
                    {
                        break;
                    }
                }
            }, canceltoken);

            return servertask;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 서버 시작
        /// <br/>
        /// <br/> 파라미터 : 
        /// <br/>       [in] accpet         -  연결요청 Socket 의 Accept Socket
        /// <br/>       [in] headbuffer     -  패킷의 헤드 byte[]
        /// <br/>       [in] token          -  수신 task 의 token 
        /// <br/>
        /// <br/> 반 환 값 : Task 수신 대기 서버 시작 task 
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="accpet">        [in] 연결요청 Socket 의 Accept Socket   </param>
        /// <param name="headbuffer">    [in] 패킷의 헤드 byte[]        </param>
        /// <param name="token">         [in] 수신 task 의 token       </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void StartServer(Socket accpet, byte[] headbuffer, CancellationToken token)
        {
            try
            {
                Receive(accpet, headbuffer, token);
            }
            catch (Exception e)
            {
#if DEBUG
                Debug.WriteLine(e.Message);
#endif
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 연결 socket 별    KeepAlive 설정 
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] client            -  연결요청 Socket 의 Accept Socket
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void InitSocket(Socket client)
        {
            int size = sizeof(UInt32);
            UInt32 on = 1;
            UInt32 keepAliveInterval = 10000;   // Send a packet once every 10 seconds.
            UInt32 retryInterval = 2_000;        // If no response, resend every second.
            byte[] inArray = new byte[size * 3];
            Array.Copy(BitConverter.GetBytes(on), 0, inArray, 0, size);
            Array.Copy(BitConverter.GetBytes(keepAliveInterval), 0, inArray, size, size);
            Array.Copy(BitConverter.GetBytes(retryInterval), 0, inArray, size * 2, size);
            client.IOControl(IOControlCode.KeepAliveValues, inArray, null);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> socket 수신 함수
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] client       -  연결요청 Socket 의 Accept Socket
        /// <br/>       [in] headbuffer   -  수신 패킷의 헤드 buffersize
        /// <br/>       [in] token        -  수신 task 
        /// <br/> 
        /// <br/> 반 환 값 : string | 오류 없이 수신 종료시 공백 오류 로 인한 수신대기 해제시 오류 메시지
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="client">       [in] 연결요청 Socket 의 Accept Socket        </param>
        /// <param name="headbuffer">   [in] 수신 패킷의 헤드 buffersize           </param>
        /// <param name="token">        [in] 수신 task        </param>
        /// <returns>   string | 오류 없이 수신 종료시 공백 오류 로 인한 수신대기 해제시 오류 메시지    </returns>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private string Receive(Socket client, byte[] headbuffer, CancellationToken token)
        {
            string message = string.Empty;
            while (true)
            {
                try
                {
                    if (token.IsCancellationRequested)
                    {
                        break;
                    }

                    if (client.Connected == false)
                    {
                        break;
                    }

                    int rxbytes_size = client.Receive(headbuffer, SocketFlags.None);
                    ProcEvent_RxEvent(rxbytes_size,headbuffer, client);
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                    break;
                }
            }
            return message;
        }

        #region Event 호출

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 연결 이벤트 호출
        /// <br/> 
        /// <br/> 파라미터 : 
        /// <br/>       [in] client     -  연결요청 Socket 의 Accept Socket
        /// <br/>       [in] value      -  true 값
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="client">   [in] 연결요청 Socket 의 Accept Socket  </param>
        /// <param name="value">    [in] true 값   </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_ConnectEvent(Socket client, bool value)
        {
            if (Event_connect != null)
            {
                Event_connect(this, new ConnectEventArgs(client, value));
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 연결 끊김 및 종료 이벤트 호출
        /// <br/> 
        /// <br/> 파라미터 :  
        /// <br/>       [in] client     -  연결요청 Socket 의 Accept Socket
        /// <br/>       [in] value      -  false 값
        /// <br/> 
        /// <br/> 반 환 값 : -
        /// <br/> 
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="client">   [in] 연결요청 Socket 의 Accept Socket  </param>
        /// <param name="value">    [in] false 값  </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_DisConnectEvent(Socket client, bool value)
        {
            if (Event_disconnect != null)
            {
                Event_disconnect(this, new ConnectEventArgs(client, value));
                ClientRemoveSocket(client);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// <br/> 수신 알람 이벤트
        /// <br/>
        /// <br/> 파라미터 :  
        /// <br/>       [in] rxsize       -  연결요청 Socket 의 Accept Socket
        /// <br/>       [in] headbuffer   -  수신 패킷의 헤드 buffersize
        /// <br/>       [in] client       -  수신 socket
        /// <br/>
        /// <br/> 반 환 값 : -
        /// <br/>
        /// <br/> 작 성 자 : 강현우
        /// <br/> 작 성 일 : 2025년 06월 30일
        /// </summary>        
        /// <param name="rxsize">       [in] 연결요청 Socket 의 Accept Socket        </param>
        /// <param name="headbuffer">   [in] 수신 패킷의 헤드 buffersize       </param>
        /// <param name="client">       [in] 수신 socket      </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcEvent_RxEvent(int rxsize, byte[] headbuffer, Socket client)
        {
            if (Event_Rxmessage != null)
            {
                Event_Rxmessage(this, new RxEventArgs(rxsize,headbuffer, client));
            }
        }

        #endregion

        public static class Defines
        {
            public static int OneSec = 1000;
            public static int DefaultBufferSize = 1024;
        }

        public class ConnectEventArgs : EventArgs
        {
            public bool ConnectState { get; set; }

            private Socket _socket;
            public Socket Client { get { return _socket; } }

            public ConnectEventArgs(Socket client, bool ConnectedState)
            {
                this._socket = client;
                this.ConnectState = ConnectedState;
            }
        }

        public class RxEventArgs : EventArgs
        {

            private Socket _socket;
            public Socket Client { get { return _socket; } }

            public byte[] headbuffer { get; set; }

            public int Rxsize { get; set; }

            public RxEventArgs(int rxsize,byte[] headebuffer, Socket clinet)
            {

                this._socket = clinet;
                this.Rxsize = rxsize;
                this.headbuffer = headebuffer;
            }
        }
    }
}
