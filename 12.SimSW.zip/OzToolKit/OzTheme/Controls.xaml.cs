﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace OzTheme
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 클래스명 : CornerRadiusHelper
    /// 설    명 : OzTheme 이벤트 제어 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2024년 06월 19일    
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    ///
    public partial class Controls
    {
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 종료 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
        private void Click_CloseWindow(object sender, RoutedEventArgs e)
        {
            if (e.Source != null)
                this.CloseWind(Window.GetWindow((FrameworkElement)e.Source));            
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 복원 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
        private void Click_AutoMinimize(object sender, RoutedEventArgs e)
        {
            if (e.Source != null)
                this.MaximizeRestore(Window.GetWindow((FrameworkElement)e.Source));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 최소화 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
        private void Click_Minimize(object sender, RoutedEventArgs e)
        {
            if (e.Source != null)
                this.MinimizeWind(Window.GetWindow((FrameworkElement)e.Source));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 종료 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
        public void CloseWind(Window window) => window?.Close();

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 최대화 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
        public void MaximizeRestore(Window window)
        {
            if (window != null)
            {
                switch (window.WindowState)
                {
                    default:
                    case WindowState.Normal:
                        window.WindowState = WindowState.Maximized;
                        break;

                    case WindowState.Minimized:
                    case WindowState.Maximized:
                        window.WindowState = WindowState.Normal;
                        break;
                }
            }                
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 함수설명 : Window 최소화 이벤트 처리
        /// 파라미터 : -        
        ///	반 환 값 : -
        /// 작 성 자 : 장봉석
        /// 작 성 일 : 2024년 06월 19일    
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void MinimizeWind(Window window)
        {
            if (window != null)
                window.WindowState = WindowState.Minimized;
        }
    }
}
