﻿using System.Windows;

namespace OzTheme.Attached 
{
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 클래스명 : CornerRadiusHelper
    /// 설    명 : OzTheme 설정 클래스
    /// 작 성 자 : 장봉석
    /// 작 성 일 : 2024년 06월 19일    
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public static class CornerRadiusHelper 
    {
        public static readonly DependencyProperty ValueProperty = DependencyProperty.RegisterAttached("Value", typeof(CornerRadius), typeof(CornerRadiusHelper), new PropertyMetadata(new CornerRadius(0)));

        public static void SetValue(DependencyObject element, CornerRadius value) => element.SetValue(ValueProperty, value);

        public static CornerRadius GetValue(DependencyObject element) => (CornerRadius)element.GetValue(ValueProperty);
    }
}