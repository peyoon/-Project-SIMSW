﻿using OzNet;
using ICD;
using System;
using System.Net.Sockets;
using System.Windows;
using OzUtil;
using System.Runtime.InteropServices;
using System.Windows.Controls;

namespace TestServer
{
    public partial class MainWindow : Window
    {
        private TCPServer m_server;
        private Socket m_clientSocket;
        private string m_sClientAddress = "N/A";
        private byte m_byClient_ID = 1;


        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
            this.Closing += MainWindow_Closing;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            m_server = new TCPServer(9112);
            m_server.Event_NotifyConnectClient += OnClientConnected;
            m_server.Event_NotifyDisconnectClient += OnClientDisconnected;
            m_server.Event_NotifyReceived += OnDataReceived;
            m_server.StartServer();
            LogEvent("서버 시작 PORT 9112. 운용 대기");
        }

        private void MainWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            m_server?.StopServer();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 새로운 클라이언트가 접속했을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 새로 접속한 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnClientConnected(Socket clientSocket)
        {
            m_clientSocket = clientSocket;
            m_sClientAddress = clientSocket.RemoteEndPoint.ToString();
            LogEvent($"연동 접속: {m_sClientAddress} ");

            //LogEvent($"연동 접속: {clientSocket.RemoteEndPoint} ");
            Dispatcher.Invoke(() => sendAngleButton.IsEnabled = true);

            try
            {
                // 'Active' (활성화)를 의미하는 0을 데이터로 설정합니다.
                uint activeValue = 0;

                // '시스템 로그인' 패킷(T_ReqLogin) 생성
                var packet = new T_ReqLogin
                {
                    header = new T_Header
                    {
                        identifier = ICD.ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD.ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD.ICD_RDR.MSG_ID_LOGIN,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqLogin>() - Marshal.SizeOf<T_Header>())
                    },
                    unActive = activeValue
                };

                int dataSize = Marshal.SizeOf<T_ReqLogin>() - Marshal.SizeOf<T_Header>();
                LogEvent($"[SEND] 시스템 로그인 명령 | identifier: 0x{packet.header.identifier:X4}, unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {dataSize} | unActive: {activeValue} (Active)");

                // Endian 변환
                packet.header.identifier = OzNet.Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = OzNet.Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = OzNet.Endian.Swap(packet.header.unSize);
                packet.unActive = OzNet.Endian.Swap(packet.unActive);

                // 패킷 전송
                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"시스템 로그인 명령 전송 중 오류 발생: {ex.Message}");
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 클라이언트의 접속이 끊어졌을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 접속이 끊어진 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnClientDisconnected(Socket clientSocket)
        {
            LogEvent($"연결 해제: {m_sClientAddress}");

            m_clientSocket = null;

            m_sClientAddress = "알 수 없는 클라이언트";

            Dispatcher.Invoke(() => {
                sendAngleButton.IsEnabled = false;
            });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 클라이언트로부터 데이터를 수신했을 때 호출되는 이벤트 핸들러입니다.
        /// <br/> 작 성 자 : 윤은평
        /// <br/> 작 성 일 : 2025년 10월 01일
        /// </summary>
        /// <param name="clientSocket"> [in] 데이터를 수신한 클라이언트의 소켓 </param>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 클라이언트로부터 데이터를 수신했을 때 호출되는 이벤트 핸들러입니다.
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void OnDataReceived(Socket clientSocket)
        {
            if (clientSocket == null || !clientSocket.Connected) return;

            try
            {
                // 1. 헤더(8바이트)를 먼저 받음
                int headerSize = Marshal.SizeOf<T_Header>();
                byte[] headerBytes = m_server.Recieve(clientSocket, headerSize);
                if (headerBytes == null) return;

                T_Header rawHeader = MarshalHelper.ByteToStructure<T_Header>(headerBytes, headerBytes.Length);

                ushort identifier = Endian.Swap(rawHeader.identifier);
                ushort bodySize = Endian.Swap(rawHeader.unSize);
                ushort messageId = Endian.Swap(rawHeader.unMessageId);
                byte senderId = rawHeader.bySenderId;
                byte receiverId = rawHeader.byReceiverId;

                if (messageId == 0) return;

                m_byClient_ID = senderId;

                byte[] bodyBytes = null;

                // 데이터가 있는 경우에만 데이터를 수신합니다.
                if (bodySize > 0)
                {
                    bodyBytes = m_server.Recieve(clientSocket, bodySize);
                    if (bodyBytes == null) return;
                }

                byte[] fullPacketBytes = new byte[headerSize + bodySize];
                Buffer.BlockCopy(headerBytes, 0, fullPacketBytes, 0, headerSize);
                if (bodySize > 0)
                {
                    Buffer.BlockCopy(bodyBytes, 0, fullPacketBytes, headerSize, bodySize);
                }

                ushort totalSizeForLog = (ushort)(headerSize + bodySize);

                switch (messageId)
                {
                    case ICD_RDR.MSG_ID_PAN_TILT_ACK:
                    case ICD_RDR.MSG_ID_LOGIN_ACK:
                    case ICD_RDR.MSG_ID_A_ZOOM_CTRL_ACK:
                    case ICD_RDR.MSG_ID_B_ZOOM_CTRL_ACK:
                    case ICD_RDR.MSG_ID_STATUS_REQ_ACK:
                        ProcessEventPacket(messageId, fullPacketBytes, identifier, totalSizeForLog, bodySize, senderId, receiverId);
                        break;

                    case ICD_RDR.MSG_ID_GPS_DATA_ACK:
                        ProcessGpsPacket(fullPacketBytes, identifier, totalSizeForLog, bodySize, senderId, receiverId);
                        break;

                    default:
                        LogEvent($"[WARNING] Received Unknown Packet | ID: 0x{messageId:X4}, Size: {totalSizeForLog}, From: {senderId}, To: {receiverId}");
                        break;
                }
            }
            catch (ObjectDisposedException) {}
            catch (Exception ex)
            {
                LogEvent($"[ERROR] 예외 에러 : {ex.Message}");
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 이벤트성 패킷(ACK 등)을 공통으로 처리하고 로그를 생성
        /// 파라미터 : [in] messageId       - 패킷의 메시지 ID
        ///            [in] fullPacketBytes - 헤더를 포함한 전체 패킷의 바이트 배열
        ///            [in] identifier      - 패킷의 식별자
        ///            [in] totalSize       - 패킷의 전체 크기
        ///            [in] bodySize        - 패킷의 데이터(Body) 크기
        ///            [in] senderId        - 송신자 ID
        ///            [in] receiverId      - 수신자 ID
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcessEventPacket(ushort messageId, byte[] fullPacketBytes, ushort identifier, ushort totalSize, int bodySize, byte senderId, byte receiverId)
        {
            string logMsg = "";
            string headerInfo = $"identifier: 0x{identifier:X4}, bySenderId: {senderId}, byReceiverId: {receiverId}, " +
                                  $"unMessageId: 0x{messageId:X4}, unSize: {bodySize} | ";

            switch (messageId)
            {
                case ICD_RDR.MSG_ID_PAN_TILT_ACK:
                    var dirPacket = MarshalHelper.ByteToStructure<T_AckDirection>(fullPacketBytes, fullPacketBytes.Length);
                    ushort pan = Endian.Swap(dirPacket.unPan);
                    short tilt = Endian.Swap(dirPacket.sTilt);
                    logMsg = $"[RECV] 방위각 고각 ACK | {headerInfo}unPan: {pan}, sTilt: {tilt}";

                    // 클라이언트로부터 받은 값으로 서버 UI(텍스트박스)를 업데이트
                    Dispatcher.Invoke(() => {
                        uiTextBox_pan.Text = pan.ToString();
                        uiTextBox_tilt.Text = tilt.ToString();
                    });
                    break;

                case ICD_RDR.MSG_ID_LOGIN_ACK:
                    var loginPacket = MarshalHelper.ByteToStructure<T_AckLogin>(fullPacketBytes, fullPacketBytes.Length);
                    uint activeStatus = Endian.Swap(loginPacket.active);
                    logMsg = $"[RECV] 로그인 상태 ACK | {headerInfo}active: {activeStatus}";

                    // 클라이언트의 실제 상태(0:DeActive, 1:Active)에 맞춰 서버 UI(라디오 버튼)를 업데이트
                    Dispatcher.Invoke(() => {
                        if (activeStatus == 1) // 클라이언트가 'Active' 상태이면
                        {
                            // 서버의 'Active' 명령 버튼을 선택
                            uiRadioButton_LoginActive.IsChecked = true;
                        }
                        else // 클라이언트가 'DeActive' 상태이면
                        {
                            // 서버의 'DeActive' 명령 버튼을 선택
                            uiRadioButton_LoginDeActive.IsChecked = true;
                        }
                    });
                    break;

                case ICD_RDR.MSG_ID_A_ZOOM_CTRL_ACK:
                    var zoomPacket = MarshalHelper.ByteToStructure<T_AckScaleA>(fullPacketBytes, fullPacketBytes.Length);
                    uint scaleValue = Endian.Swap(zoomPacket.unScale);
                    logMsg = $"[RECV] A 배율 변환 ACK | {headerInfo}unScale: {scaleValue}";

                    // 클라이언트로부터 받은 값으로 서버 UI(라디오 버튼)를 업데이트
                    Dispatcher.Invoke(() => {
                        if (scaleValue == 0x01) uiRadioButton_Scale3x.IsChecked = true;
                        else if (scaleValue == 0x02) uiRadioButton_Scale11x.IsChecked = true;
                        else if (scaleValue == 0x04) uiRadioButton_Scale40x.IsChecked = true;
                    });
                    break;

                case ICD_RDR.MSG_ID_B_ZOOM_CTRL_ACK:
                    var b_zoomPacket = MarshalHelper.ByteToStructure<T_AckScaleB>(fullPacketBytes, fullPacketBytes.Length);
                    uint b_scaleValue = Endian.Swap(b_zoomPacket.unScale);
                    logMsg = $"[RECV] B 배율 변환 ACK | {headerInfo}unScale: {b_scaleValue}";
                    break;

                case ICD_RDR.MSG_ID_STATUS_REQ_ACK:
                    var statusPacket = MarshalHelper.ByteToStructure<T_AckStatus>(fullPacketBytes, fullPacketBytes.Length);
                    uint status = Endian.Swap(statusPacket.unStatus);
                    logMsg = $"[RECV] 상태 ACK | {headerInfo}unStatus: {status}";
                    break;
            }
            LogEvent(logMsg);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 레이더 위치 정보 패킷을 처리하고 주기 로그 창에 출력
        /// 파라미터 : [in] fullPacketBytes - 헤더를 포함한 전체 패킷의 바이트 배열
        ///            [in] identifier      - 패킷의 식별자
        ///            [in] totalSize       - 패킷의 전체 크기
        ///            [in] bodySize        - 패킷의 데이터(Body) 크기
        ///            [in] senderId        - 송신자 ID
        ///            [in] receiverId      - 수신자 ID
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void ProcessGpsPacket(byte[] fullPacketBytes, ushort identifier, ushort totalSize, int bodySize, byte senderId, byte receiverId)
        {
            string logMsg;

            // 친구 코드의 데이터 크기인 24바이트를 기준으로 처리합니다.
            if (bodySize == 24)
            {
                // 친구 코드와 동일한 구조체로 변환합니다 (Pack=1 제거, fDirection 없음).
                var packet = MarshalHelper.ByteToStructure<T_AckGpsData>(fullPacketBytes, fullPacketBytes.Length);

                // [수정] float 값은 Little Endian으로 오므로 Swap을 하지 않습니다.
                float lat = packet.fLatitude;
                float lon = packet.fLongitude;

                // ushort 값은 Big Endian으로 오므로 Swap을 유지합니다.
                ushort alt = Endian.Swap(packet.unAltitude);

                logMsg = $"[RECV] GPS 데이터 ACK | " +
                         $"identifier: 0x{identifier:X4}, bySenderId: {senderId}, byReceiverId: {receiverId}, " +
                         $"unMessageId: 0x{ICD_RDR.MSG_ID_GPS_DATA_ACK:X4}, unSize: {bodySize} | " +
                         $"fLatitude: {lat:F4}, byNSIndicator: {(char)packet.byNSIndicator}, fLongitude: {lon:F4}, byEWIndicator: {(char)packet.byEWIndicator}, " +
                         $"unAltitude: {alt}";
            }
            else
            {
                logMsg = $"[ERROR] Unknown GPS Packet Received with data size: {bodySize}";
            }

            LogPeriodic(logMsg);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// '상태 요청' 버튼 클릭 시, 클라이언트로 '상태 요청' 패킷을 전송하는 이벤트 핸들러
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 관련 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendStatusRequestButton_Click(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }

            try
            {
                var packet = new T_ReqStatus
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD_RDR.MSG_ID_STATUS_REQ,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqStatus>() - Marshal.SizeOf<T_Header>())
                    }
                };
                int dataSize = Marshal.SizeOf<T_ReqStatus>() - Marshal.SizeOf<T_Header>(); 
                LogEvent($"[SEND] 상태 요청 | identifier: 0x{packet.header.identifier:X4}, unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {dataSize}");

                // Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);

                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending status request: {ex.Message}");
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 'Send Angle Command' 버튼 클릭 시 입력된 값으로 방향 지점 탐색 명령을 클라이언트로 전송
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 관련 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 01일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendAngleButton_Click(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }
            try
            {
                ushort pan = ushort.Parse(uiTextBox_pan.Text);
                short tilt = short.Parse(uiTextBox_tilt.Text);

                T_ReqDirection packet = new T_ReqDirection
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD_RDR.MSG_ID_CONTROLLER_POS_SEARCH,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqDirection>() - Marshal.SizeOf<T_Header>())
                    },
                    unPan = pan,
                    sTilt = tilt
                };

                int dataSize = Marshal.SizeOf<T_ReqDirection>() - Marshal.SizeOf<T_Header>();
                // 로그 출력을 위해 원본 헤더 정보를 변수에 저장
                var headerInfo = $"identifier: 0x{packet.header.identifier:X4}, bySenderId: {packet.header.bySenderId}, byReceiverId: {packet.header.byReceiverId}, " +
                                 $"unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {dataSize} | ";
                LogEvent($"[SEND] 방향 지점 탐색 | {headerInfo}unPan: {pan}, sTilt: {tilt}");

                // Endian 변환
                packet.header.identifier = Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = Endian.Swap(packet.header.unSize);
                packet.unPan = Endian.Swap(packet.unPan);
                packet.sTilt = Endian.Swap(packet.sTilt);

                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending command: {ex.Message}");
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 배율 제어 라디오 버튼 클릭 시, 해당하는 'A 배율 제어 명령' 패킷을 클라이언트로 전송
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 관련 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_RadioButton_Scale(object sender, RoutedEventArgs e)
        {
            if (m_clientSocket == null) { LogEvent("No client connected."); return; }

            RadioButton radioButton = sender as RadioButton;
            if (radioButton == null || radioButton.Tag == null) return;

            // A배율 명령과 B배율 명령 모두에 사용할 '코드 값' (1, 2, 4)
            uint scaleValue = Convert.ToUInt32(radioButton.Tag);

            try
            {
                // ==========================================================
                // 1. A 배율 제어 명령 (0xAA02) 전송
                // ==========================================================
                var a_packet = new T_ReqScaleA
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD_RDR.MSG_ID_A_ZOOM_CTRL,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqScaleA>() - Marshal.SizeOf<T_Header>())
                    },
                    unScale = scaleValue
                };

                int a_dataSize = Marshal.SizeOf<T_ReqScaleA>() - Marshal.SizeOf<T_Header>();
                var a_headerInfo = $"identifier: 0x{a_packet.header.identifier:X4}, bySenderId: {a_packet.header.bySenderId}, byReceiverId: {a_packet.header.byReceiverId}, " +
                                 $"unMessageId: 0x{a_packet.header.unMessageId:X4}, unSize: {a_dataSize} | ";
                LogEvent($"[SEND] A 배율 제어 명령 | {a_headerInfo}unScale: {scaleValue}");

                a_packet.header.identifier = Endian.Swap(a_packet.header.identifier);
                a_packet.header.unMessageId = Endian.Swap(a_packet.header.unMessageId);
                a_packet.header.unSize = Endian.Swap(a_packet.header.unSize);
                a_packet.unScale = Endian.Swap(a_packet.unScale);
                SendPacket(a_packet);

                // ==========================================================
                // 2. B 배율 제어 명령 (0xAB02) 전송
                // ==========================================================
                var b_packet = new T_ReqScaleB
                {
                    header = new T_Header
                    {
                        identifier = ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD_RDR.MSG_ID_B_ZOOM_CTRL,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqScaleB>() - Marshal.SizeOf<T_Header>())
                    },
                    unScale = scaleValue // B배율 명령에도 동일한 '코드 값'을 사용
                };

                int b_dataSize = Marshal.SizeOf<T_ReqScaleB>() - Marshal.SizeOf<T_Header>();
                var b_headerInfo = $"identifier: 0x{b_packet.header.identifier:X4}, bySenderId: {b_packet.header.bySenderId}, byReceiverId: {b_packet.header.byReceiverId}, " +
                                 $"unMessageId: 0x{b_packet.header.unMessageId:X4}, unSize: {b_dataSize} | ";
                LogEvent($"[SEND] B 배율 제어 명령 | {b_headerInfo}unScale: {scaleValue}");

                b_packet.header.identifier = Endian.Swap(b_packet.header.identifier);
                b_packet.header.unMessageId = Endian.Swap(b_packet.header.unMessageId);
                b_packet.header.unSize = Endian.Swap(b_packet.header.unSize);
                b_packet.unScale = Endian.Swap(b_packet.unScale);
                SendPacket(b_packet);
            }
            catch (Exception ex)
            {
                LogEvent($"Error sending scale command: {ex.Message}");
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 제네릭 타입을 사용하여 모든 종류의 데이터 구조체(패킷)를 직렬화하고
        /// 연결된 클라이언트 소켓으로 전송
        /// 파라미터 : [in] packet - 전송할 데이터 구조체 (제네릭 타입)
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void SendPacket<T>(T packet) where T : struct
        {
            if (m_clientSocket == null) return;

            byte[] data = MarshalHelper.StructToByte(packet);
            m_server.Send(m_clientSocket, data);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// UI 스레드 접근을 보장하며 주기 로그(Periodic Log) 창에 메시지를 출력
        /// 파라미터 : [in] message - 주기 로그 창에 출력할 문자열 메시지
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LogPeriodic(string message)
        {
            Dispatcher.Invoke(() =>
            {
                uiTextBox_periodicLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                uiTextBox_periodicLog.ScrollToEnd();
            });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// UI 스레드 접근을 보장하며 이벤트 로그(Event Log) 창에 메시지를 출력
        /// 파라미터 : [in] message - 이벤트 로그 창에 출력할 문자열 메시지
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void LogEvent(string message)
        {
            Dispatcher.Invoke(() =>
            {
                uiTextBox_eventLog.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\n");
                uiTextBox_eventLog.ScrollToEnd();
            });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        /// <summary>
        /// 로그인(Active/DeActive) 라디오 버튼 클릭 시, 해당하는 '시스템 로그인' 명령 패킷을
        /// 클라이언트로 전송
        /// 파라미터 : [in] sender - 이벤트를 발생시킨 객체
        ///            [in] e     - 이벤트 관련 데이터
        /// 반 환 값 : -
        /// 작 성 자 : 윤은평
        /// 작 성 일 : 2025년 10월 14일
        /// </summary>
        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        private void Click_RadioButton_Login(object sender, RoutedEventArgs e)
        {
            // 1. 클라이언트 연결 상태 확인
            if (m_clientSocket == null)
            {
                LogEvent("클라이언트가 연결되지 않았습니다.");
                return;
            }

            // 2. 클릭된 라디오 버튼 정보 가져오기
            var radioButton = sender as RadioButton;
            if (radioButton == null || radioButton.Tag == null) return;

            // Tag 값(0 또는 1)을 uint로 변환
            uint activeValue = Convert.ToUInt32(radioButton.Tag);

            try
            {
                // 3. '시스템 로그인' 패킷(T_ReqLogin) 생성
                var packet = new T_ReqLogin
                {
                    header = new T_Header
                    {
                        identifier = ICD.ICD_RDR.MSG_SIMSW_INDICATOR,
                        bySenderId = ICD.ICD_RDR.SIMSRV_ID,
                        byReceiverId = m_byClient_ID,
                        unMessageId = ICD.ICD_RDR.MSG_ID_LOGIN,
                        unSize = (ushort)(Marshal.SizeOf<T_ReqLogin>() - Marshal.SizeOf<T_Header>())
                    },
                    unActive = activeValue
                };

                // 4. 전송 전, 상세 로그 출력
                string statusText = (activeValue == 0) ? "Active" : "DeActive";
                int dataSize = Marshal.SizeOf<T_ReqLogin>() - Marshal.SizeOf<T_Header>();
                string headerInfo = $"identifier: 0x{packet.header.identifier:X4}, bySenderId: {packet.header.bySenderId}, byReceiverId: {packet.header.byReceiverId}, " +
                                     $"unMessageId: 0x{packet.header.unMessageId:X4}, unSize: {dataSize} | ";
                LogEvent($"[SEND] 시스템 로그인 명령 | {headerInfo}unActive: {activeValue} ({statusText})");

                // 5. Endian 변환
                packet.header.identifier = OzNet.Endian.Swap(packet.header.identifier);
                packet.header.unMessageId = OzNet.Endian.Swap(packet.header.unMessageId);
                packet.header.unSize = OzNet.Endian.Swap(packet.header.unSize);
                packet.unActive = OzNet.Endian.Swap(packet.unActive);

                // 6. 패킷 전송
                SendPacket(packet);
            }
            catch (Exception ex)
            {
                LogEvent($"시스템 로그인 명령 전송 중 오류 발생: {ex.Message}");
            }
        }

        private void Click_Button_ClearLog(object sender, RoutedEventArgs e)
        {
            // 이벤트 로그 텍스트박스의 내용을 모두 지d움
            uiTextBox_eventLog.Clear();

            // 주기 로그 텍스트박스의 내용을 모두 지움
            uiTextBox_periodicLog.Clear();
        }
    }
}