﻿using System.Runtime.InteropServices;

namespace ICD
{
    public enum E_OperationStatus
    {
        Terminated,
        Operating,
        Standby
    }
    [StructLayout(LayoutKind.Sequential)]
     public class ICD_RDR
    {
        public const int MSG_SIMSW_INDICATOR            = (0xABCD);
        public const int SIMSRV_ID                      = (0x00);

        // SIMSRV Send (SIMSRV->SIMSW)
        public const int MSG_ID_A_ZOOM_CTRL             = (0xAA02);
        public const int MSG_ID_B_ZOOM_CTRL             = (0xAB02);
        public const int MSG_ID_CONTROLLER_POS_SEARCH   = (0xAC03);
        public const int MSG_ID_STATUS_REQ              = (0xAD01);
        public const int MSG_ID_LOGIN                   = (0xFFAA);
        //public const int MSG_ID_TARGET_COORD_CTRL       = (0xAC02);

        // SIMSW Send (SIMSW->SIMSRV)
        public const int MSG_ID_A_ZOOM_CTRL_ACK         = (0xAA02);
        public const int MSG_ID_B_ZOOM_CTRL_ACK         = (0xAB02);
        public const int MSG_ID_PAN_TILT_ACK            = (0xAC02);
        public const int MSG_ID_STATUS_REQ_ACK          = (0xAD01);
        public const int MSG_ID_GPS_DATA_ACK            = (0xAE01);
        public const int MSG_ID_LOGIN_ACK               = (0xFFAA);
    }


    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// 통신 패킷의 공통 헤더 구조체
    /// 작 성 자 : 윤은평
    /// 작 성 일 : 2025년 09월 28일
    /// </summary>
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_Header
    {
        public ushort identifier;
        public byte bySenderId;
        public byte byReceiverId;
        public ushort unMessageId;
        public ushort unSize;
    }


    /// <summary>A 배율 제어 명령 (Message ID: 0xAA02)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_ReqScaleA
    {
        public T_Header header;
        // 배율 데이터 (0x01: 3배, 0x02: 11배, 0x04: 40배)
        public uint unScale;
    }

    /// <summary>B 배율 제어 명령 (Message ID: 0xAB02)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_ReqScaleB
    {
        public T_Header header;
        /// <summary>배율 데이터 (0x01: 3배, 0x02: 11배, 0x04: 40배)</summary>
        public uint unScale;
    }

    /// <summary>방향 지점 탐색 (Message ID: 0xAC03)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_ReqDirection
    {
        public T_Header header;
        public ushort unPan; // 방위각 (0~6399)
        public short sTilt; // 고각 (-1000~1000)
    }

    /// <summary>상태 요청 (Message ID: 0xAD01)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_ReqStatus
    {
        public T_Header header;
    }

    /// <summary>시스템 로그인 (Message ID: 0xFFAA)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_ReqLogin
    {
        public T_Header header;
        /// <summary>로그인 상태 (0: Active, 1: DeActive)</summary>
        public uint unActive;
    }

    //==============================================================================================================
    // 제어 응답 (Target -> Host)
    //==============================================================================================================

    /// <summary>A 배율 변환 ACK (Message ID: 0xAA02)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckScaleA
    {
        public T_Header header;
        public uint unScale;
    }

    /// <summary>B 배율 변환 ACK (Message ID: 0xAB02)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckScaleB
    {
        public T_Header header;
        public uint unScale;
    }

    /// <summary>방향 지점 ACK (Message ID: 0xAC02)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckDirection
    {
        public T_Header header;
        public ushort unPan;
        public short sTilt;
    }

    /// <summary>상태 ACK (Message ID: 0xAD01)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckStatus
    {
        public T_Header header;
        public uint unStatus; //0x02
    }

    /// <summary>GPS 데이터 ACK (Message ID: 0xAE01)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckGpsData
    {
        public T_Header header;
        public float fLatitude;
        public byte byNSIndicator;
        public float fLongitude;
        public byte byEWIndicator;
        public ushort unAltitude;
        public ushort unYear;
        public byte byMonth;
        public byte byDay;
        public byte byHour;
        public byte byMinute;
        public byte bySecond;
        public ushort unStatic1;
        public byte byStatic2;
        public byte byStatic3;
        public byte byReserved;
    }

    /// <summary>로그인 상태 ACK (Message ID: 0xFFAA)</summary>
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct T_AckLogin
    {
        public T_Header header;
        public uint active;
    }
}
